<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'p3qr_settings' );

global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ( '_p3qr_code', '_p3qr_target', '_p3qr_hash' )" );

$upload = wp_upload_dir();
$dir    = trailingslashit( $upload['basedir'] ) . 'p3qr-codes';

if ( is_dir( $dir ) ) {
	foreach ( (array) glob( $dir . '/*' ) as $file ) {
		if ( is_file( $file ) ) {
			unlink( $file );
		}
	}
	@rmdir( $dir );
}
