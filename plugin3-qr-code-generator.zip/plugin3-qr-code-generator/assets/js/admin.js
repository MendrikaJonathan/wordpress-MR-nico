/* global jQuery, p3qrAdmin */
(function ($) {
	'use strict';

	var ajax = p3qrAdmin.ajax;
	var nonce = p3qrAdmin.nonce;

	function call(action, data) {
		return $.post(ajax, $.extend({ action: 'p3qr_' + action, nonce: nonce }, data));
	}

	function refreshImg(id, url) {
		var sep = url.indexOf('?') > -1 ? '&' : '?';
		$('[data-p3qr-img="' + id + '"]').attr('src', url + sep + 't=' + Date.now());
	}

	$(document).on('click', '.p3qr-js-regen', function (e) {
		e.preventDefault();
		var $btn = $(this);
		var id = $btn.data('id');
		$btn.prop('disabled', true);
		call('regen', { id: id })
			.done(function (r) {
				if (r && r.success) {
					refreshImg(id, r.data.url);
					if ($('[data-p3qr-row="' + id + '"] .p3qr-missing').length) {
						window.location.reload();
					}
				} else {
					window.alert((r && r.data && r.data.message) || p3qrAdmin.i18n.error);
				}
			})
			.fail(function () { window.alert(p3qrAdmin.i18n.error); })
			.always(function () { $btn.prop('disabled', false); });
	});

	$(document).on('click', '.p3qr-js-del', function (e) {
		e.preventDefault();
		if (!window.confirm(p3qrAdmin.i18n.confirmDelete)) { return; }
		var $btn = $(this);
		$btn.prop('disabled', true);
		call('delete', { id: $btn.data('id') }).always(function () { window.location.reload(); });
	});

	$(document).on('click', '.p3qr-js-copy', function (e) {
		e.preventDefault();
		var $btn = $(this);
		var $input = $btn.closest('p').find('.p3qr-shortcode');
		if (!$input.length || !$input.val()) { return; }
		$input[0].select();
		try { document.execCommand('copy'); } catch (err) { /* noop */ }
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText($input.val());
		}
		$btn.text(p3qrAdmin.i18n.copied);
		window.setTimeout(function () { $btn.text(p3qrAdmin.i18n.copy); }, 1500);
	});

	$('#p3qr-custom-go').on('click', function () {
		var $btn = $(this);
		var url = $('#p3qr-custom-url').val();
		if (!url) { return; }
		$btn.prop('disabled', true);
		call('custom_url', { url: url })
			.done(function (r) {
				var $box = $('#p3qr-custom-result').removeClass('p3qr-hidden');
				if (r && r.success) {
					$box.html(
						'<p><img src="' + r.data.url + '" width="140" height="140" alt="" /></p>' +
						'<p><input type="text" class="regular-text p3qr-shortcode" readonly value="' +
						String(r.data.shortcode).replace(/"/g, '&quot;') + '" /> ' +
						'<button type="button" class="button button-small p3qr-js-copy">' + p3qrAdmin.i18n.copy + '</button></p>'
					);
				} else {
					$box.html('<p class="p3qr-error">' + ((r && r.data && r.data.message) || p3qrAdmin.i18n.error) + '</p>');
				}
			})
			.fail(function () { window.alert(p3qrAdmin.i18n.error); })
			.always(function () { $btn.prop('disabled', false); });
	});

	function runBulk(force) {
		var $bar = $('#p3qr-progress').removeClass('p3qr-hidden');
		var $fill = $bar.find('.p3qr-progress-bar');
		var $text = $bar.find('.p3qr-progress-text');
		var processedTotal = 0;
		var errors = [];

		function step(offset) {
			call('bulk_step', { offset: offset, force: force ? 1 : 0 })
				.done(function (r) {
					if (!(r && r.success)) {
						$text.text(p3qrAdmin.i18n.error);
						return;
					}
					var total = parseInt(r.data.total, 10) || 0;
					processedTotal += parseInt(r.data.processed, 10) || 0;
					errors = errors.concat(r.data.errors || []);

					var pct = total ? Math.min(100, Math.round((processedTotal / total) * 100)) : 100;
					$fill.css('width', pct + '%');
					$text.text(processedTotal + ' / ' + total);

					if (r.data.remaining) {
						step(parseInt(r.data.cursor, 10) || 0);
					} else {
						var msg = p3qrAdmin.i18n.done.replace('%d', processedTotal);
						if (errors.length) {
							msg += ' (' + errors.length + ' ' + p3qrAdmin.i18n.errorsLabel + ')';
							window.console.warn('P3QR bulk errors:', errors);
						}
						$text.text(msg);
					}
				})
				.fail(function () { $text.text(p3qrAdmin.i18n.error); });
		}

		step(0);
	}

	$('#p3qr-bulk-missing').on('click', function () { runBulk(false); });
	$('#p3qr-bulk-force').on('click', function () { runBulk(true); });
})(jQuery);
