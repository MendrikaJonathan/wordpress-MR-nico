# Plugin3 – QR Code Generator (WordPress)

Plugin WordPress qui **génère automatiquement un QR code** pointant vers chaque fichier de la médiathèque : PDF, images, documents Office, ZIP, MP3, MP4, etc.

Chaque QR code est une image PNG stockée localement dans `wp-content/uploads/p3qr-codes/` — aucune API externe, aucune dépendance Composer.

---

## Fonctionnalités

| Fonctionnalité | Détail |
|---|---|
| Génération automatique | Un QR est créé dès qu’un fichier suivi est ajouté à la médiathèque (`add_attachment`) |
| Types de fichiers | Liste configurable : pdf, jpg, png, gif, webp, svg, zip, doc(x), xls(x), ppt(x), txt, csv, mp3, mp4 |
| Médiathèque | Colonne « QR Code » avec aperçu + champ dédié dans la fenêtre média (aperçu, téléchargement, shortcode) |
| Page admin « QR Codes » | Liste des fichiers suivis, recherche, régénération/suppression unitaires, téléchargement PNG |
| Génération en masse | Boutons « Générer les QR manquants » / « Tout régénérer » avec barre de progression (traitement par lots AJAX) |
| URL personnalisée | Créer un QR depuis n’importe quelle URL de fichier, sans upload |
| Shortcode | `[qr_code]` pour affichage en front-office |
| Personnalisation | Taille du PNG, marge, niveau de correction d’erreur (L/M/Q/H), couleurs motif/fond, fond transparent |
| Régénération intelligente | Empreinte (hash) de l’URL + réglages : les QR obsolètes sont recréés automatiquement |

## Installation

1. Copiez le dossier `plugin3-qr-code-generator` dans `wp-content/plugins/`
   (ou zippez-le puis : **Extensions → Ajouter → Téléverser une extension**).
2. Activez **« Plugin3 – QR Code Generator »**.
3. Ouvrez le menu **QR Codes** du tableau de bord.

Prérequis : WordPress 6.0+, PHP 7.4+ avec l’extension **GD** (standard chez tous les hébergeurs).

## Utilisation

### Automatique
Uploadez simplement un fichier (ex. `rapport.pdf`) dans **Médias → Ajouter** : le QR code apparaît immédiatement dans la colonne « QR Code » de la médiathèque.

### Shortcode

```
[qr_code id="123"]
```

Attributs disponibles :

| Attribut | Défaut | Description |
|---|---|---|
| `id` | — | ID du média dont l’URL sera encodée |
| `url` | — | URL directe alternative (si `id` absent) |
| `size` | `200` | Largeur d’affichage en px (50–1000) |
| `alt` | « QR code » | Texte alternatif |
| `align` | — | `left`, `center` ou `right` |
| `link` | `false` | `true` = le QR devient un lien cliquable vers le fichier |
| `class` | — | Classes CSS supplémentaires |

Exemples :

```
[qr_code id="42" size="300" align="center" link="true"]
[qr_code url="https://exemple.com/catalogue-2026.pdf" size="250"]
```

### Fonction PHP (template)

```php
<?php if ( $url = p3qr_get_qr_url( 123 ) ) : ?>
    <img src="<?php echo esc_url( $url ); ?>" width="200" alt="QR code" />
<?php endif; ?>
```

## Réglages (QR Codes → Réglages)

- **Génération automatique** : on/off
- **Types de fichiers suivis** : cases à cocher par extension
- **Taille du PNG** : 100–1200 px (les modules restent nets : redimensionnement au pixel près)
- **Marge** : zone silencieuse en modules (4 recommandé)
- **Correction d’erreur** : L 7 % / M 15 % / Q 25 % / H 30 %
- **Couleurs** : motif, arrière-plan, option fond transparent

## Filtres pour développeurs

```php
// Restreindre les extensions suivies
add_filter( 'p3qr_allowed_extensions', fn( array $exts ) => array_intersect( $exts, [ 'pdf', 'png' ] ) );

// Personnaliser les options de rendu
add_filter( 'p3qr_build_args', function ( array $args ) {
    $args['level'] = 'H';
    return $args;
} );

// Changer la cible encodée pour un média donné
add_filter( 'p3qr_target_url', function ( string $url, int $attachment_id ) {
    return $url; // votre logique
}, 10, 2 );
```

## Structure du projet

```
plugin3-qr-code-generator/
├── qr-code-generator.php          # Fichier principal (bootstrap)
├── uninstall.php                  # Nettoyage complet à la désinstallation
├── readme.txt                     # Fiche standard WordPress
├── includes/
│   ├── lib/phpqrcode.php          # Bibliothèque PHP QR Code (LGPL v3, embarquée)
│   ├── class-p3qr-builder.php     # Moteur de rendu PNG (phpqrcode + GD, recoloration)
│   ├── class-p3qr-core.php        # Réglages, génération auto, stockage, téléchargement
│   ├── class-p3qr-media.php       # Colonne médiathèque + champ média
│   ├── class-p3qr-admin.php       # Menu, pages admin, AJAX, génération en masse
│   └── class-p3qr-shortcode.php   # Shortcode [qr_code] + helper p3qr_get_qr_url()
├── assets/
│   ├── css/admin.css
│   └── js/admin.js                # Actions AJAX, barre de progression, copie shortcode
└── tests/
    └── cli-test.php               # Test CLI autonome (php tests/cli-test.php)
```

## Test rapide hors WordPress

```bash
php tests/cli-test.php
```

Génère 4 QR d’exemple (noir/blanc, coloré, transparent, texte) dans `tests/output/`.

## Notes techniques & sécurité

- Les QR encodent l’**URL publique** du fichier : assurez-vous que les médias visés sont accessibles publiquement.
- Toutes les actions admin sont protégées par nonces et capacités (`upload_files` / `manage_options`).
- Le mode « URL personnalisée » côté visiteur est limité à 30 générations/heure (anti-abus).
- La désinstallation supprime l’option, les métadonnées `_p3qr_*` et le dossier `uploads/p3qr-codes/`.
- Bibliothèque embarquée : [PHP QR Code](https://sourceforge.net/projects/phpqrcode/) (LGPL v3) ; le reste du plugin est sous GPL v2 ou ultérieure.

## Changelog

### 1.0.0
- Version initiale : génération automatique, page admin, génération en masse, shortcode, réglages complets.
