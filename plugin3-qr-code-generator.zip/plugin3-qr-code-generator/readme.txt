=== Plugin3 – QR Code Generator ===
Contributors: plugin3
Tags: qr code, media, pdf, fichiers, shortcode
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Génère automatiquement un QR code pointant vers chaque fichier de la médiathèque (PDF, image, document…).

== Description ==

Dès qu’un fichier suivi (PDF, image, ZIP, document Office, MP3, MP4…) est ajouté à la médiathèque, le plugin crée automatiquement une image PNG de QR code qui pointe vers l’URL directe du fichier.

Fonctionnalités :

* Génération automatique à l’upload (activable/désactivable)
* Colonne « QR Code » dans la médiathèque et champ dédié dans la fenêtre média
* Page d’administration « QR Codes » : liste des fichiers, régénération, suppression, téléchargement PNG
* Génération en masse avec barre de progression
* Création de QR codes depuis une URL arbitraire (sans upload)
* Shortcode `[qr_code]` pour afficher un QR code sur une page ou un article
* Réglages : types de fichiers suivis, taille, marge, correction d’erreur, couleurs, fond transparent
* Aucune dépendance externe : bibliothèque PHP QR Code embarquée + GD

== Installation ==

1. Copiez le dossier `plugin3-qr-code-generator` dans `/wp-content/plugins/`, ou importez son zip via Extensions → Ajouter → Téléverser.
2. Activez « Plugin3 – QR Code Generator ».
3. Ouvrez le menu « QR Codes » du tableau de bord.

== Frequently Asked Questions ==

= Comment afficher un QR code dans un article ? =

Utilisez `[qr_code id="123"]` (ID du média) ou `[qr_code url="https://exemple.com/fichier.pdf"]`.

= Les réglages modifiés s’appliquent-ils aux QR existants ? =

Oui : les QR obsolètes sont détectés puis régénérés automatiquement lors de leur prochain affichage, ou via « Tout régénérer ».

== Changelog ==

= 1.0.0 =
* Version initiale.
