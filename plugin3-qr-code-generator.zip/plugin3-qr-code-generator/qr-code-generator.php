<?php
/**
 * Plugin Name:       Plugin3 – QR Code Generator
 * Description:       Génère automatiquement un QR code pointant vers chaque fichier de la médiathèque (PDF, image, document…) avec affichage par shortcode, colonne média et téléchargement PNG.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Plugin3
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       plugin3-qr-code-generator
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'P3QR_VERSION', '1.0.0' );
define( 'P3QR_FILE', __FILE__ );
define( 'P3QR_DIR', plugin_dir_path( __FILE__ ) );
define( 'P3QR_URL', plugin_dir_url( __FILE__ ) );

require_once P3QR_DIR . 'includes/lib/phpqrcode.php';
require_once P3QR_DIR . 'includes/class-p3qr-builder.php';
require_once P3QR_DIR . 'includes/class-p3qr-core.php';
require_once P3QR_DIR . 'includes/class-p3qr-media.php';
require_once P3QR_DIR . 'includes/class-p3qr-admin.php';
require_once P3QR_DIR . 'includes/class-p3qr-shortcode.php';

register_activation_hook( __FILE__, array( 'P3QR_Core', 'activate' ) );

P3QR_Core::init();
P3QR_Media::init();
P3QR_Admin::init();
P3QR_Shortcode::init();
