<?php

define( 'P3QR_CLI', true );

require __DIR__ . '/../includes/lib/phpqrcode.php';
require __DIR__ . '/../includes/class-p3qr-builder.php';

$out_dir = __DIR__ . '/output';
if ( ! is_dir( $out_dir ) ) {
	mkdir( $out_dir, 0755, true );
}

$cases = array(
	array( 'name' => 'pdf-noir-blanc', 'text' => 'https://exemple.com/fichiers/rapport-annuel.pdf', 'args' => array( 'size' => 300 ) ),
	array( 'name' => 'image-couleur',  'text' => 'https://exemple.com/medias/photo.png',          'args' => array( 'size' => 500, 'fg' => '#123456', 'bg' => '#ffffff' ) ),
	array( 'name' => 'doc-transparent','text' => 'https://exemple.com/docs/contrat.docx',         'args' => array( 'size' => 250, 'level' => 'H', 'transparent' => true ) ),
	array( 'name' => 'texte-simple',   'text' => 'Hello QR Plugin3',                              'args' => array( 'size' => 200, 'margin' => 2 ) ),
);

$failures = 0;

foreach ( $cases as $i => $case ) {
	try {
		$bin  = P3QR_Builder::build( $case['text'], $case['args'] );
		$path = "{$out_dir}/{$i}-{$case['name']}.png";
		file_put_contents( $path, $bin );
		$info = getimagesize( $path );
		printf(
			"OK  %-18s %-45s -> %s (%dx%d, %d octets)\n",
			$case['name'],
			mb_substr( $case['text'], 0, 45 ),
			basename( $path ),
			$info[0],
			$info[1],
			filesize( $path )
		);
	} catch ( Exception $e ) {
		$failures++;
		printf( "ECHEC %s : %s\n", $case['name'], $e->getMessage() );
	}
}

exit( $failures > 0 ? 1 : 0 );
