<?php

defined( 'ABSPATH' ) || exit;

class P3QR_Core {

	const OPTION      = 'p3qr_settings';
	const DIR_NAME    = 'p3qr-codes';
	const META_CODE   = '_p3qr_code';
	const META_TARGET = '_p3qr_target';
	const META_HASH   = '_p3qr_hash';

	public static $mime_patterns = array(
		'pdf'  => array( 'application/pdf' ),
		'jpg'  => array( 'image/jpeg' ),
		'jpeg' => array( 'image/jpeg' ),
		'png'  => array( 'image/png' ),
		'gif'  => array( 'image/gif' ),
		'webp' => array( 'image/webp' ),
		'svg'  => array( 'image/svg' ),
		'zip'  => array( 'application/zip', 'application/x-zip' ),
		'doc'  => array( 'application/msword' ),
		'docx' => array( 'wordprocessingml' ),
		'xls'  => array( 'application/vnd.ms-excel', 'application/msexcel' ),
		'xlsx' => array( 'spreadsheetml' ),
		'ppt'  => array( 'application/vnd.ms-powerpoint' ),
		'pptx' => array( 'presentationml' ),
		'txt'  => array( 'text/plain' ),
		'csv'  => array( 'text/csv' ),
		'mp3'  => array( 'audio/mpeg', 'audio/mp3' ),
		'mp4'  => array( 'video/mp4' ),
	);

	public static function init() {
		load_plugin_textdomain( 'plugin3-qr-code-generator', false, dirname( plugin_basename( P3QR_FILE ) ) . '/languages' );

		add_action( 'add_attachment', array( __CLASS__, 'on_add_attachment' ) );
		add_action( 'edit_attachment', array( __CLASS__, 'on_edit_attachment' ) );
		add_action( 'delete_attachment', array( __CLASS__, 'on_delete_attachment' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_send_download' ) );
	}

	public static function activate() {
		wp_mkdir_p( self::uploads_dir() );
		if ( false === get_option( self::OPTION ) ) {
			add_option( self::OPTION, self::defaults() );
		}
	}

	public static function defaults() {
		return array(
			'auto'        => 1,
			'types'       => array_keys( self::$mime_patterns ),
			'size'        => 400,
			'margin'      => 4,
			'level'       => 'M',
			'fg'          => '#000000',
			'bg'          => '#ffffff',
			'transparent' => 0,
		);
	}

	public static function settings() {
		static $cache = null;
		if ( null === $cache ) {
			$cache = wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
		}
		return $cache;
	}

	public static function get( $key ) {
		$s = self::settings();
		return isset( $s[ $key ] ) ? $s[ $key ] : null;
	}

	public static function allowed_extensions() {
		$exts = (array) self::get( 'types' );
		$exts = array_intersect( $exts, array_keys( self::$mime_patterns ) );
		return apply_filters( 'p3qr_allowed_extensions', array_values( $exts ) );
	}

	public static function build_args() {
		$s = self::settings();
		$args = array(
			'size'        => (int) $s['size'],
			'level'       => (string) $s['level'],
			'margin'      => (int) $s['margin'],
			'fg'          => (string) $s['fg'],
			'bg'          => (string) $s['bg'],
			'transparent' => (bool) $s['transparent'],
		);
		return apply_filters( 'p3qr_build_args', $args );
	}

	public static function uploads_dir() {
		$up = wp_upload_dir();
		return trailingslashit( $up['basedir'] ) . self::DIR_NAME;
	}

	public static function uploads_url() {
		$up = wp_upload_dir();
		return trailingslashit( $up['baseurl'] ) . self::DIR_NAME;
	}

	public static function extension_of( $attachment_id ) {
		$file = get_attached_file( $attachment_id );
		if ( ! $file ) {
			return '';
		}
		return strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
	}

	public static function is_tracked( $attachment_id ) {
		return in_array( self::extension_of( $attachment_id ), self::allowed_extensions(), true );
	}

	public static function target_url( $attachment_id ) {
		$url = wp_get_attachment_url( $attachment_id );
		if ( ! $url ) {
			$url = get_post_field( 'guid', $attachment_id );
		}
		return apply_filters( 'p3qr_target_url', $url, $attachment_id );
	}

	public static function code_rel( $attachment_id ) {
		return self::DIR_NAME . '/media-' . (int) $attachment_id . '.png';
	}

	public static function code_path( $attachment_id ) {
		$up = wp_upload_dir();
		return trailingslashit( $up['basedir'] ) . self::code_rel( $attachment_id );
	}

	public static function code_url( $attachment_id ) {
		$up = wp_upload_dir();
		return trailingslashit( $up['baseurl'] ) . self::code_rel( $attachment_id );
	}

	public static function hash_for( $target ) {
		return md5( (string) $target . '|' . wp_json_encode( self::build_args() ) . '|' . P3QR_VERSION );
	}

	public static function ensure( $attachment_id, $force = false ) {
		$attachment_id = (int) $attachment_id;

		if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) {
			return new WP_Error( 'p3qr_invalid', __( 'Média introuvable.', 'plugin3-qr-code-generator' ) );
		}
		if ( ! self::is_tracked( $attachment_id ) ) {
			return new WP_Error( 'p3qr_untracked', __( 'Type de fichier non suivi.', 'plugin3-qr-code-generator' ) );
		}

		$target = self::target_url( $attachment_id );
		if ( ! $target ) {
			return new WP_Error( 'p3qr_no_target', __( 'URL du fichier introuvable.', 'plugin3-qr-code-generator' ) );
		}

		$hash = self::hash_for( $target );
		$path = self::code_path( $attachment_id );

		if ( ! $force && file_exists( $path ) && (string) get_post_meta( $attachment_id, self::META_HASH, true ) === $hash ) {
			return self::code_url( $attachment_id );
		}

		try {
			self::write_png( $target, $path );
		} catch ( Exception $e ) {
			return new WP_Error( 'p3qr_build', $e->getMessage() );
		}

		update_post_meta( $attachment_id, self::META_CODE, self::code_rel( $attachment_id ) );
		update_post_meta( $attachment_id, self::META_TARGET, $target );
		update_post_meta( $attachment_id, self::META_HASH, $hash );

		return self::code_url( $attachment_id );
	}

	public static function generate_for_url( $url ) {
		$url = esc_url_raw( (string) $url );

		if ( ! $url || ! preg_match( '#^https?://#i', $url ) ) {
			return new WP_Error( 'p3qr_bad_url', __( 'URL invalide.', 'plugin3-qr-code-generator' ) );
		}

		$name = 'url-' . md5( $url ) . '.png';
		$path = trailingslashit( self::uploads_dir() ) . $name;

		if ( ! file_exists( $path ) ) {
			if ( ! current_user_can( 'upload_files' ) ) {
				$count = (int) get_transient( 'p3qr_url_gen_count' );
				if ( $count >= 30 ) {
					return new WP_Error( 'p3qr_rate', __( 'Trop de générations de QR codes, réessayez plus tard.', 'plugin3-qr-code-generator' ) );
				}
				set_transient( 'p3qr_url_gen_count', $count + 1, HOUR_IN_SECONDS );
			}

			try {
				self::write_png( $url, $path );
			} catch ( Exception $e ) {
				return new WP_Error( 'p3qr_build', $e->getMessage() );
			}
		}

		return trailingslashit( self::uploads_url() ) . $name;
	}

	protected static function write_png( $text, $dest ) {
		wp_mkdir_p( dirname( $dest ) );
		$bin = P3QR_Builder::build( $text, self::build_args() );
		if ( false === file_put_contents( $dest, $bin ) ) {
			throw new RuntimeException( __( 'Impossible d’écrire le PNG dans le dossier uploads.', 'plugin3-qr-code-generator' ) );
		}
	}

	public static function delete_code( $attachment_id ) {
		$attachment_id = (int) $attachment_id;
		$path          = self::code_path( $attachment_id );
		if ( file_exists( $path ) ) {
			wp_delete_file( $path );
		}
		delete_post_meta( $attachment_id, self::META_CODE );
		delete_post_meta( $attachment_id, self::META_TARGET );
		delete_post_meta( $attachment_id, self::META_HASH );
	}

	public static function on_add_attachment( $attachment_id ) {
		if ( ! self::get( 'auto' ) || ! self::is_tracked( $attachment_id ) ) {
			return;
		}
		self::ensure( $attachment_id );
	}

	public static function on_edit_attachment( $attachment_id ) {
		if ( ! self::is_tracked( $attachment_id ) ) {
			return;
		}

		$target = self::target_url( $attachment_id );
		if ( ! $target ) {
			return;
		}

		if ( file_exists( self::code_path( $attachment_id ) ) ) {
			if ( (string) get_post_meta( $attachment_id, self::META_HASH, true ) !== self::hash_for( $target ) ) {
				self::ensure( $attachment_id, true );
			}
			return;
		}

		if ( self::get( 'auto' ) ) {
			self::ensure( $attachment_id );
		}
	}

	public static function on_delete_attachment( $attachment_id ) {
		self::delete_code( $attachment_id );
	}

	public static function maybe_send_download() {
		if ( empty( $_GET['p3qr_dl'] ) ) {
			return;
		}

		if ( ! current_user_can( 'upload_files' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'plugin3-qr-code-generator' ), 403 );
		}

		$attachment_id = absint( $_GET['p3qr_dl'] );
		$path          = self::code_path( $attachment_id );

		if ( ! $attachment_id || ! file_exists( $path ) ) {
			wp_die( esc_html__( 'QR code introuvable.', 'plugin3-qr-code-generator' ), 404 );
		}

		$title = sanitize_title( get_the_title( $attachment_id ) );
		if ( ! $title ) {
			$title = 'media-' . $attachment_id;
		}

		nocache_headers();
		header( 'Content-Type: image/png' );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Content-Disposition: attachment; filename="qr-' . $title . '.png"' );
		readfile( $path );
		exit;
	}
}
