<?php

defined( 'ABSPATH' ) || exit;

class P3QR_Media {

	public static function init() {
		add_filter( 'manage_media_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_media_custom_column', array( __CLASS__, 'column_content' ), 10, 2 );
		add_filter( 'attachment_fields_to_edit', array( __CLASS__, 'attachment_field' ), 10, 2 );
	}

	public static function columns( $columns ) {
		$columns['p3qr'] = __( 'QR Code', 'plugin3-qr-code-generator' );
		return $columns;
	}

	public static function column_content( $column, $attachment_id ) {
		if ( 'p3qr' !== $column ) {
			return;
		}

		if ( ! P3QR_Core::is_tracked( $attachment_id ) ) {
			echo '<span aria-hidden="true">—</span>';
			return;
		}

		$url = P3QR_Core::ensure( $attachment_id );

		if ( is_wp_error( $url ) ) {
			printf(
				'<button type="button" class="button button-small p3qr-js-regen" data-id="%d">%s</button>',
				esc_attr( $attachment_id ),
				esc_html__( 'Générer', 'plugin3-qr-code-generator' )
			);
			return;
		}

		printf(
			'<a href="%1$s" target="_blank" rel="noopener"><img src="%1$s" data-p3qr-img="%2$d" width="44" height="44" alt="%3$s" class="p3qr-mini" /></a>',
			esc_url( $url ),
			esc_attr( $attachment_id ),
			esc_attr__( 'Aperçu du QR code', 'plugin3-qr-code-generator' )
		);
	}

	public static function attachment_field( $fields, $post ) {
		$attachment_id = (int) $post->ID;

		if ( ! P3QR_Core::is_tracked( $attachment_id ) ) {
			return $fields;
		}

		$url      = P3QR_Core::ensure( $attachment_id );
		$file_url = P3QR_Core::target_url( $attachment_id );
		$dl       = add_query_arg( 'p3qr_dl', $attachment_id, home_url( '/' ) );

		ob_start();
		?>
		<div class="p3qr-field">
			<?php if ( is_wp_error( $url ) ) : ?>
				<p class="p3qr-error"><?php echo esc_html( $url->get_error_message() ); ?></p>
				<button type="button" class="button p3qr-js-regen" data-id="<?php echo esc_attr( $attachment_id ); ?>"><?php esc_html_e( 'Générer le QR code', 'plugin3-qr-code-generator' ); ?></button>
			<?php else : ?>
				<p><img src="<?php echo esc_url( $url ); ?>" data-p3qr-img="<?php echo esc_attr( $attachment_id ); ?>" width="110" height="110" alt="" class="p3qr-preview" /></p>
				<p>
					<a class="button button-small" href="<?php echo esc_url( $dl ); ?>"><?php esc_html_e( 'Télécharger le PNG', 'plugin3-qr-code-generator' ); ?></a>
					<a class="button button-small" href="<?php echo esc_url( $file_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Ouvrir le fichier', 'plugin3-qr-code-generator' ); ?></a>
					<button type="button" class="button-link p3qr-js-regen" data-id="<?php echo esc_attr( $attachment_id ); ?>"><?php esc_html_e( 'Régénérer', 'plugin3-qr-code-generator' ); ?></button>
				</p>
				<p>
					<input type="text" class="p3qr-shortcode" readonly value="<?php echo esc_attr( '[qr_code id="' . $attachment_id . '"]' ); ?>" />
					<button type="button" class="button button-small p3qr-js-copy"><?php esc_html_e( 'Copier', 'plugin3-qr-code-generator' ); ?></button>
				</p>
			<?php endif; ?>
		</div>
		<?php
		$html = ob_get_clean();

		$fields['p3qr_info'] = array(
			'label' => __( 'QR Code', 'plugin3-qr-code-generator' ),
			'input' => 'html',
			'html'  => $html,
		);

		return $fields;
	}
}
