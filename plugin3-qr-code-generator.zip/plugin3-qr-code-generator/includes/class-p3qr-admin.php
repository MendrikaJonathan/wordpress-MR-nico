<?php

defined( 'ABSPATH' ) || exit;

class P3QR_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_p3qr_save_settings', array( __CLASS__, 'save_settings' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( P3QR_FILE ), array( __CLASS__, 'action_links' ) );

		add_action( 'wp_ajax_p3qr_regen', array( __CLASS__, 'ajax_regen' ) );
		add_action( 'wp_ajax_p3qr_delete', array( __CLASS__, 'ajax_delete' ) );
		add_action( 'wp_ajax_p3qr_custom_url', array( __CLASS__, 'ajax_custom_url' ) );
		add_action( 'wp_ajax_p3qr_bulk_step', array( __CLASS__, 'ajax_bulk_step' ) );
	}

	public static function menu() {
		add_menu_page(
			__( 'QR Codes', 'plugin3-qr-code-generator' ),
			__( 'QR Codes', 'plugin3-qr-code-generator' ),
			'upload_files',
			'p3qr-codes',
			array( __CLASS__, 'render_list' ),
			'dashicons-grid-view',
			58
		);
		add_submenu_page(
			'p3qr-codes',
			__( 'Tous les fichiers', 'plugin3-qr-code-generator' ),
			__( 'Tous les fichiers', 'plugin3-qr-code-generator' ),
			'upload_files',
			'p3qr-codes',
			array( __CLASS__, 'render_list' )
		);
		add_submenu_page(
			'p3qr-codes',
			__( 'Réglages QR Code', 'plugin3-qr-code-generator' ),
			__( 'Réglages', 'plugin3-qr-code-generator' ),
			'manage_options',
			'p3qr-settings',
			array( __CLASS__, 'render_settings' )
		);
	}

	public static function assets( $hook ) {
		$screen   = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$is_ours  = $screen && false !== strpos( (string) $screen->id, 'p3qr-' );
		$is_media = in_array( $hook, array( 'upload.php', 'post.php', 'post-new.php' ), true );

		if ( ! $is_ours && ! $is_media ) {
			return;
		}

		wp_enqueue_style( 'p3qr-admin', P3QR_URL . 'assets/css/admin.css', array(), P3QR_VERSION );
		wp_enqueue_script( 'p3qr-admin', P3QR_URL . 'assets/js/admin.js', array( 'jquery' ), P3QR_VERSION, true );
		wp_localize_script(
			'p3qr-admin',
			'p3qrAdmin',
			array(
				'ajax'  => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'p3qr_admin' ),
				'i18n'  => array(
					'confirmDelete' => __( 'Supprimer ce QR code ?', 'plugin3-qr-code-generator' ),
					'copy'          => __( 'Copier', 'plugin3-qr-code-generator' ),
					'copied'        => __( 'Copié !', 'plugin3-qr-code-generator' ),
					'done'          => __( 'Terminé : %d fichier(s) traité(s).', 'plugin3-qr-code-generator' ),
					'errorsLabel'   => __( 'erreur(s)', 'plugin3-qr-code-generator' ),
					'error'         => __( 'Une erreur est survenue.', 'plugin3-qr-code-generator' ),
				),
			)
		);
	}

	public static function action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'admin.php?page=p3qr-settings' ) ) . '">' . esc_html__( 'Réglages', 'plugin3-qr-code-generator' ) . '</a>'
		);
		return $links;
	}

	protected static function guard_ajax() {
		check_ajax_referer( 'p3qr_admin', 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Accès refusé.', 'plugin3-qr-code-generator' ) ), 403 );
		}
	}

	public static function ajax_regen() {
		self::guard_ajax();

		$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$url = P3QR_Core::ensure( $id, true );

		if ( is_wp_error( $url ) ) {
			wp_send_json_error( array( 'message' => $url->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'url'      => $url,
				'download' => add_query_arg( 'p3qr_dl', $id, home_url( '/' ) ),
			)
		);
	}

	public static function ajax_delete() {
		self::guard_ajax();

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		P3QR_Core::delete_code( $id );

		wp_send_json_success();
	}

	public static function ajax_custom_url() {
		self::guard_ajax();

		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';
		$res = P3QR_Core::generate_for_url( $url );

		if ( is_wp_error( $res ) ) {
			wp_send_json_error( array( 'message' => $res->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'url'       => $res,
				'shortcode' => '[qr_code url="' . $url . '"]',
			)
		);
	}

	public static function ajax_bulk_step() {
		self::guard_ajax();

		$offset = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;
		$force  = ! empty( $_POST['force'] );
		$batch  = 20;

		$query = new WP_Query(
			array(
				'post_type'              => 'attachment',
				'post_status'            => 'inherit',
				'posts_per_page'         => $batch,
				'offset'                 => $offset,
				'post_mime_type'         => self::mime_query(),
				'fields'                 => 'ids',
				'orderby'                => 'date',
				'order'                  => 'DESC',
				'update_post_term_cache' => false,
			)
		);

		$ok     = 0;
		$errors = array();

		foreach ( $query->posts as $id ) {
			$res = P3QR_Core::ensure( (int) $id, $force );
			if ( is_wp_error( $res ) ) {
				$errors[] = array(
					'id'      => (int) $id,
					'message' => $res->get_error_message(),
				);
			} else {
				$ok++;
			}
		}

		$total = (int) $query->found_posts;
		$next  = $offset + count( $query->posts );

		wp_send_json_success(
			array(
				'processed' => count( $query->posts ),
				'ok'        => $ok,
				'errors'    => $errors,
				'cursor'    => $next,
				'remaining' => $next < $total && count( $query->posts ) > 0,
				'total'     => $total,
			)
		);
	}

	protected static function mime_query() {
		$patterns = array();
		foreach ( P3QR_Core::allowed_extensions() as $ext ) {
			foreach ( isset( P3QR_Core::$mime_patterns[ $ext ] ) ? (array) P3QR_Core::$mime_patterns[ $ext ] : array() as $pattern ) {
				$patterns[] = $pattern;
			}
		}
		return array_values( array_unique( $patterns ) );
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'plugin3-qr-code-generator' ) );
		}
		check_admin_referer( 'p3qr_settings' );

		$post = isset( $_POST['p3qr'] ) ? (array) wp_unslash( $_POST['p3qr'] ) : array();
		$s    = P3QR_Core::defaults();

		$s['auto']  = empty( $post['auto'] ) ? 0 : 1;
		$types      = isset( $post['types'] ) ? array_map( 'sanitize_key', (array) $post['types'] ) : array();
		$s['types'] = array_values( array_intersect( $types, array_keys( P3QR_Core::$mime_patterns ) ) );

		$s['size']   = max( 100, min( 1200, isset( $post['size'] ) ? absint( $post['size'] ) : 400 ) );
		$s['margin'] = max( 0, min( 10, isset( $post['margin'] ) ? absint( $post['margin'] ) : 4 ) );

		$level      = strtoupper( sanitize_key( isset( $post['level'] ) ? $post['level'] : 'M' ) );
		$s['level'] = in_array( $level, array( 'L', 'M', 'Q', 'H' ), true ) ? $level : 'M';

		$s['fg']          = self::hex_color( isset( $post['fg'] ) ? $post['fg'] : '', '#000000' );
		$s['bg']          = self::hex_color( isset( $post['bg'] ) ? $post['bg'] : '', '#ffffff' );
		$s['transparent'] = empty( $post['transparent'] ) ? 0 : 1;

		update_option( P3QR_Core::OPTION, $s );

		wp_safe_redirect( add_query_arg( array( 'page' => 'p3qr-settings', 'updated' => '1' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	protected static function hex_color( $value, $fallback ) {
		$value = trim( (string) $value );
		return preg_match( '/^#[0-9a-fA-F]{6}$/', $value ) ? $value : $fallback;
	}

	public static function render_list() {
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';

		$query = new WP_Query(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 20,
				'paged'          => $paged,
				's'              => $search,
				'post_mime_type' => self::mime_query(),
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		$last_error = get_transient( 'p3qr_last_error' );
		?>
		<div class="wrap p3qr-wrap-admin">
			<h1><?php esc_html_e( 'QR Codes – Fichiers', 'plugin3-qr-code-generator' ); ?></h1>

			<?php if ( $last_error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $last_error ); ?></p></div>
			<?php endif; ?>

			<div class="card p3qr-card">
				<h2 class="title"><?php esc_html_e( 'Générer un QR code depuis une URL', 'plugin3-qr-code-generator' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Collez l’URL directe d’un fichier (PDF, image, document…) pour créer un QR code sans passer par la médiathèque.', 'plugin3-qr-code-generator' ); ?></p>
				<p>
					<input type="url" id="p3qr-custom-url" class="regular-text" placeholder="https://exemple.com/fichier.pdf" />
					<button type="button" class="button button-primary" id="p3qr-custom-go"><?php esc_html_e( 'Générer', 'plugin3-qr-code-generator' ); ?></button>
				</p>
				<div id="p3qr-custom-result" class="p3qr-hidden"></div>
			</div>

			<div class="card p3qr-card">
				<h2 class="title"><?php esc_html_e( 'Génération en masse', 'plugin3-qr-code-generator' ); ?></h2>
				<p>
					<button type="button" class="button" id="p3qr-bulk-missing"><?php esc_html_e( 'Générer les QR manquants', 'plugin3-qr-code-generator' ); ?></button>
					<button type="button" class="button" id="p3qr-bulk-force"><?php esc_html_e( 'Tout régénérer', 'plugin3-qr-code-generator' ); ?></button>
				</p>
				<div id="p3qr-progress" class="p3qr-hidden">
					<span class="p3qr-progress-track"><span class="p3qr-progress-bar" style="width:0%"></span></span>
					<span class="p3qr-progress-text"></span>
				</div>
			</div>

			<form method="get" class="p3qr-search">
				<input type="hidden" name="page" value="p3qr-codes" />
				<p class="search-box">
					<label class="screen-reader-text" for="p3qr-search-input"><?php esc_html_e( 'Rechercher un fichier', 'plugin3-qr-code-generator' ); ?></label>
					<input type="search" id="p3qr-search-input" name="s" value="<?php echo esc_attr( $search ); ?>" />
					<button class="button"><?php esc_html_e( 'Rechercher', 'plugin3-qr-code-generator' ); ?></button>
				</p>
			</form>

			<table class="widefat striped p3qr-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Fichier', 'plugin3-qr-code-generator' ); ?></th>
						<th><?php esc_html_e( 'Type', 'plugin3-qr-code-generator' ); ?></th>
						<th><?php esc_html_e( 'QR Code', 'plugin3-qr-code-generator' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'plugin3-qr-code-generator' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! $query->have_posts() ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'Aucun fichier suivi trouvé. Ajoutez des fichiers à la médiathèque ou vérifiez les types suivis dans les réglages.', 'plugin3-qr-code-generator' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $query->posts as $post ) : ?>
							<?php self::render_row( $post ); ?>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>

			<?php
			$links = paginate_links(
				array(
					'base'    => add_query_arg( 'paged', '%#%' ),
					'total'   => (int) $query->max_num_pages,
					'current' => $paged,
					'type'    => 'plain',
				)
			);
			if ( $links ) {
				echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( $links ) . '</div></div>';
			}
			?>
		</div>
		<?php
	}

	protected static function render_row( $post ) {
		$id       = (int) $post->ID;
		$url      = P3QR_Core::ensure( $id );
		$file_url = P3QR_Core::target_url( $id );
		$dl       = add_query_arg( 'p3qr_dl', $id, home_url( '/' ) );

		$title = get_the_title( $id );
		if ( ! $title ) {
			$file  = get_attached_file( $id );
			$title = $file ? basename( $file ) : 'media-' . $id;
		}
		?>
		<tr data-p3qr-row="<?php echo esc_attr( $id ); ?>">
			<td>
				<?php echo wp_get_attachment_image( $id, array( 40, 40 ), true, array( 'class' => 'p3qr-thumb' ) ); ?>
				<a href="<?php echo esc_url( $file_url ); ?>" target="_blank" rel="noopener"><strong><?php echo esc_html( $title ); ?></strong></a>
			</td>
			<td><span class="p3qr-badge p3qr-type"><?php echo esc_html( strtoupper( P3QR_Core::extension_of( $id ) ) ); ?></span></td>
			<td>
				<?php if ( is_wp_error( $url ) ) : ?>
					<span class="p3qr-badge p3qr-missing"><?php esc_html_e( 'Manquant', 'plugin3-qr-code-generator' ); ?></span>
				<?php else : ?>
					<img src="<?php echo esc_url( $url ); ?>" data-p3qr-img="<?php echo esc_attr( $id ); ?>" width="48" height="48" alt="" class="p3qr-mini" />
				<?php endif; ?>
			</td>
			<td>
				<button type="button" class="button button-small p3qr-js-regen" data-id="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Régénérer', 'plugin3-qr-code-generator' ); ?></button>
				<?php if ( ! is_wp_error( $url ) ) : ?>
					<a class="button button-small" href="<?php echo esc_url( $dl ); ?>"><?php esc_html_e( 'Télécharger', 'plugin3-qr-code-generator' ); ?></a>
					<button type="button" class="button-link p3qr-js-del" data-id="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Supprimer', 'plugin3-qr-code-generator' ); ?></button>
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}

	public static function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'plugin3-qr-code-generator' ) );
		}

		$s = P3QR_Core::settings();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Réglages – QR Code Generator', 'plugin3-qr-code-generator' ); ?></h1>

			<?php if ( ! empty( $_GET['updated'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Réglages enregistrés.', 'plugin3-qr-code-generator' ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="p3qr_save_settings" />
				<?php wp_nonce_field( 'p3qr_settings' ); ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Génération automatique', 'plugin3-qr-code-generator' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="p3qr[auto]" value="1" <?php checked( $s['auto'], 1 ); ?> />
								<?php esc_html_e( 'Créer le QR code dès qu’un fichier suivi est ajouté à la médiathèque.', 'plugin3-qr-code-generator' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Types de fichiers suivis', 'plugin3-qr-code-generator' ); ?></th>
						<td>
							<?php foreach ( P3QR_Core::$mime_patterns as $ext => $mimes ) : ?>
								<label class="p3qr-type-check">
									<input type="checkbox" name="p3qr[types][]" value="<?php echo esc_attr( $ext ); ?>" <?php checked( in_array( $ext, (array) $s['types'], true ) ); ?> />
									.<?php echo esc_html( $ext ); ?>
								</label>
							<?php endforeach; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="p3qr-size"><?php esc_html_e( 'Taille du PNG', 'plugin3-qr-code-generator' ); ?></label></th>
						<td>
							<input type="number" id="p3qr-size" name="p3qr[size]" min="100" max="1200" step="10" value="<?php echo esc_attr( $s['size'] ); ?>" class="small-text" /> px
							<p class="description"><?php esc_html_e( 'Largeur cible de l’image générée (100 à 1200 pixels).', 'plugin3-qr-code-generator' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="p3qr-margin"><?php esc_html_e( 'Marge (zone silencieuse)', 'plugin3-qr-code-generator' ); ?></label></th>
						<td>
							<input type="number" id="p3qr-margin" name="p3qr[margin]" min="0" max="10" value="<?php echo esc_attr( $s['margin'] ); ?>" class="small-text" /> <?php esc_html_e( 'modules', 'plugin3-qr-code-generator' ); ?>
							<p class="description"><?php esc_html_e( '4 est la valeur recommandée pour une lecture fiable.', 'plugin3-qr-code-generator' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="p3qr-level"><?php esc_html_e( 'Correction d’erreur', 'plugin3-qr-code-generator' ); ?></label></th>
						<td>
							<select id="p3qr-level" name="p3qr[level]">
								<option value="L" <?php selected( $s['level'], 'L' ); ?>>L — 7%</option>
								<option value="M" <?php selected( $s['level'], 'M' ); ?>>M — 15% (<?php esc_html_e( 'recommandé', 'plugin3-qr-code-generator' ); ?>)</option>
								<option value="Q" <?php selected( $s['level'], 'Q' ); ?>>Q — 25%</option>
								<option value="H" <?php selected( $s['level'], 'H' ); ?>>H — 30%</option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Couleurs', 'plugin3-qr-code-generator' ); ?></th>
						<td>
							<label>
								<input type="color" name="p3qr[fg]" value="<?php echo esc_attr( $s['fg'] ); ?>" />
								<?php esc_html_e( 'Motif', 'plugin3-qr-code-generator' ); ?>
							</label>
							&nbsp;&nbsp;
							<label>
								<input type="color" name="p3qr[bg]" value="<?php echo esc_attr( $s['bg'] ); ?>" />
								<?php esc_html_e( 'Arrière-plan', 'plugin3-qr-code-generator' ); ?>
							</label>
							&nbsp;&nbsp;
							<label>
								<input type="checkbox" name="p3qr[transparent]" value="1" <?php checked( $s['transparent'], 1 ); ?> />
								<?php esc_html_e( 'Arrière-plan transparent', 'plugin3-qr-code-generator' ); ?>
							</label>
						</td>
					</tr>
				</table>

				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
