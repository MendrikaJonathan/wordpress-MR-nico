<?php

defined( 'ABSPATH' ) || defined( 'P3QR_CLI' ) || exit;

class P3QR_Builder {

	public static function build( $text, $args = array() ) {
		if ( '' === trim( (string) $text ) ) {
			throw new RuntimeException( 'Contenu vide : impossible de générer le QR code.' );
		}

		$o = array_merge(
			array(
				'size'        => 400,
				'level'       => 'M',
				'margin'      => 4,
				'fg'          => '#000000',
				'bg'          => '#ffffff',
				'transparent' => false,
			),
			$args
		);

		$o['size']   = max( 50, min( 1200, (int) $o['size'] ) );
		$o['margin'] = max( 0, min( 10, (int) $o['margin'] ) );
		$o['level']  = in_array( strtoupper( (string) $o['level'] ), array( 'L', 'M', 'Q', 'H' ), true ) ? strtoupper( (string) $o['level'] ) : 'M';

		if ( ! function_exists( 'imagecreatetruecolor' ) ) {
			throw new RuntimeException( 'L’extension PHP GD est requise pour générer les QR codes.' );
		}

		$tmp = tempnam( sys_get_temp_dir(), 'p3qr' );

		QRcode::png( $text, $tmp, constant( 'QR_ECLEVEL_' . $o['level'] ), 1, $o['margin'] );

		$img = @imagecreatefrompng( $tmp );
		@unlink( $tmp );

		if ( ! $img ) {
			throw new RuntimeException( 'Échec de la création de l’image QR.' );
		}

		$w     = imagesx( $img );
		$h     = imagesy( $img );
		$scale = max( 1, (int) floor( $o['size'] / $w ) );

		if ( $scale > 1 ) {
			$scaled = imagescale( $img, $w * $scale, $h * $scale, IMG_NEAREST_NEIGHBOUR );
			if ( $scaled ) {
				imagedestroy( $img );
				$img = $scaled;
				$w   = imagesx( $img );
				$h   = imagesy( $img );
			}
		}

		$fg = self::hex_to_rgb( $o['fg'], array( 0, 0, 0 ) );
		$bg = self::hex_to_rgb( $o['bg'], array( 255, 255, 255 ) );

		$needs_recolor = ! empty( $o['transparent'] )
			|| 0 !== $fg[0] || 0 !== $fg[1] || 0 !== $fg[2]
			|| 255 !== $bg[0] || 255 !== $bg[1] || 255 !== $bg[2];

		if ( $needs_recolor ) {
			$out = imagecreatetruecolor( $w, $h );
			imagealphablending( $out, false );
			imagesavealpha( $out, true );

			if ( ! empty( $o['transparent'] ) ) {
				$fill = imagecolorallocatealpha( $out, $bg[0], $bg[1], $bg[2], 127 );
			} else {
				$fill = imagecolorallocate( $out, $bg[0], $bg[1], $bg[2] );
			}
			imagefilledrectangle( $out, 0, 0, $w, $h, $fill );

			$ink = imagecolorallocatealpha( $out, $fg[0], $fg[1], $fg[2], 0 );

			for ( $y = 0; $y < $h; $y++ ) {
				for ( $x = 0; $x < $w; $x++ ) {
					$c   = imagecolorat( $img, $x, $y );
					$lum = 0.299 * ( ( $c >> 16 ) & 0xFF ) + 0.587 * ( ( $c >> 8 ) & 0xFF ) + 0.114 * ( $c & 0xFF );
					if ( $lum < 128 ) {
						imagesetpixel( $out, $x, $y, $ink );
					}
				}
			}

			imagedestroy( $img );
			$img = $out;
		}

		ob_start();
		imagepng( $img, null, 6 );
		imagedestroy( $img );
		$bin = ob_get_clean();

		if ( ! $bin ) {
			throw new RuntimeException( 'Échec de l’encodage PNG.' );
		}

		return $bin;
	}

	protected static function hex_to_rgb( $hex, $fallback ) {
		$hex = trim( (string) $hex, '#' );
		if ( preg_match( '/^[0-9a-fA-F]{6}$/', $hex ) ) {
			return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
		}
		return $fallback;
	}
}
