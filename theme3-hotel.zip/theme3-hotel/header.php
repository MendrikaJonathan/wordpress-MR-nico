<?php
/**
 * En-tête du thème.
 *
 * @package theme3-hotel
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="screen-reader-text" href="#t3-contenu"><?php esc_html_e( 'Aller au contenu', 'theme3-hotel' ); ?></a>

<header class="t3-header">
	<div class="t3-container t3-header-inner">

		<div class="t3-logo-zone">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a class="t3-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<span><?php bloginfo( 'name' ); ?></span>
				</a>
			<?php endif; ?>
		</div>

		<?php
		wp_nav_menu(
			array(
				'theme_location' => 'primary',
				'container'      => 'nav',
				'container_class' => 't3-nav',
				'menu_class'     => '',
				'depth'          => 2,
				'fallback_cb'    => 't3_hotel_menu_fallback',
			)
		);
		?>

		<div class="t3-recherche-header">
			<?php get_search_form(); ?>
		</div>

		<button class="t3-burger" aria-label="<?php esc_attr_e( 'Ouvrir le menu', 'theme3-hotel' ); ?>" aria-expanded="false">
			<span></span><span></span><span></span>
		</button>

	</div>
</header>

<main id="t3-contenu">
