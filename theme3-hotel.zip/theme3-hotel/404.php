<?php
/**
 * Page 404.
 *
 * @package theme3-hotel
 */

get_header();
?>

<section class="t3-section">
	<div class="t3-container" style="text-align:center;padding:80px 20px;">
		<h1 style="font-size:clamp(4rem,10vw,7rem);margin:0;color:var(--t3-or);">404</h1>
		<h2><?php esc_html_e( 'Page introuvable', 'theme3-hotel' ); ?></h2>
		<p class="t3-sous-titre"><?php esc_html_e( 'La page que vous cherchez n\'existe pas ou a été déplacée.', 'theme3-hotel' ); ?></p>

		<div style="max-width:420px;margin:30px auto;">
			<?php get_search_form(); ?>
		</div>

		<a class="t3-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Retour à l\'accueil', 'theme3-hotel' ); ?></a>
	</div>
</section>

<?php get_footer(); ?>
