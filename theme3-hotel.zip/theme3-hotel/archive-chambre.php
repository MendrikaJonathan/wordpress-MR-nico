<?php
/**
 * Archive des chambres : grille + filtres (personnes, prix max).
 *
 * @package theme3-hotel
 */

get_header();

$personnes_selection = isset( $_GET['personnes'] ) ? absint( $_GET['personnes'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$prix_max_saisi      = isset( $_GET['prix_max'] ) ? sanitize_text_field( wp_unslash( $_GET['prix_max'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>

<section class="t3-section">
	<div class="t3-container">

		<h1 class="t3-titre-section"><?php esc_html_e( 'Nos chambres', 'theme3-hotel' ); ?></h1>
		<p class="t3-sous-titre"><?php esc_html_e( 'Choisissez la chambre qui correspond à votre séjour.', 'theme3-hotel' ); ?></p>

		<form class="t3-filtres" method="get" action="<?php echo esc_url( get_post_type_archive_link( 'chambre' ) ); ?>">
			<div class="t3-champ">
				<label for="t3-filtre-personnes"><?php esc_html_e( 'Personnes minimum', 'theme3-hotel' ); ?></label>
				<select id="t3-filtre-personnes" name="personnes">
					<option value=""><?php esc_html_e( 'Toutes', 'theme3-hotel' ); ?></option>
					<?php for ( $i = 1; $i <= 6; $i++ ) : ?>
						<option value="<?php echo esc_attr( $i ); ?>" <?php selected( $personnes_selection, $i ); ?>><?php echo esc_html( $i ); ?></option>
					<?php endfor; ?>
				</select>
			</div>

			<div class="t3-champ">
				<label for="t3-filtre-prix"><?php esc_html_e( 'Prix maximum (€)', 'theme3-hotel' ); ?></label>
				<input type="number" min="0" id="t3-filtre-prix" name="prix_max" value="<?php echo esc_attr( $prix_max_saisi ); ?>" placeholder="<?php esc_attr_e( 'Illimité', 'theme3-hotel' ); ?>">
			</div>

			<button type="submit" class="t3-btn"><?php esc_html_e( 'Filtrer', 'theme3-hotel' ); ?></button>
		</form>

		<?php if ( have_posts() ) : ?>
			<div class="t3-grille">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/carte-chambre' );
				endwhile;
				?>
			</div>

			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 2,
					'class'     => 't3-pagination',
					'prev_text' => __( '&laquo;', 'theme3-hotel' ),
					'next_text' => __( '&raquo;', 'theme3-hotel' ),
				)
			);
			?>

		<?php else : ?>
			<p class="t3-sous-titre"><?php esc_html_e( 'Aucune chambre ne correspond à ces critères.', 'theme3-hotel' ); ?></p>
		<?php endif; ?>

	</div>
</section>

<?php get_footer(); ?>
