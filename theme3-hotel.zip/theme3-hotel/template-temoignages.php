<?php
/**
 * Modèle de page témoignages.
 *
 * @package theme3-hotel
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<section class="t3-section">
		<div class="t3-container">

			<h1 class="t3-titre-section"><?php the_title(); ?></h1>

			<?php if ( has_excerpt() ) : ?>
				<p class="t3-sous-titre"><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>

			<?php
			$temoignages = new WP_Query(
				array(
					'post_type'      => 'temoignage',
					'posts_per_page' => -1,
					'no_found_rows'  => true,
				)
			);

			if ( $temoignages->have_posts() ) :
				?>
				<div class="t3-grille">
					<?php
					while ( $temoignages->have_posts() ) :
						$temoignages->the_post();
						get_template_part( 'template-parts/temoignage' );
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			<?php else : ?>
				<p class="t3-sous-titre"><?php esc_html_e( 'Aucun témoignage pour le moment.', 'theme3-hotel' ); ?></p>
			<?php endif; ?>

			<div class="entry-content t3-page-contenu">
				<?php the_content(); ?>
			</div>

		</div>
	</section>

	<?php
endwhile;

get_footer();
