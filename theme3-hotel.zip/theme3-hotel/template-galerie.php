<?php
/**
 * Modèle de page galerie photos avec lightbox.
 *
 * @package theme3-hotel
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<section class="t3-section">
		<div class="t3-container">

			<h1 class="t3-titre-section"><?php the_title(); ?></h1>

			<?php if ( has_excerpt() ) : ?>
				<p class="t3-sous-titre"><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>

			<?php
			$images = t3_hotel_images_galerie( 60 );

			if ( $images ) :
				?>
				<div class="t3-galerie">
					<?php foreach ( $images as $image_id ) : ?>
						<figure class="t3-galerie-item">
							<?php echo wp_get_attachment_image( $image_id, 't3-galerie' ); ?>
						</figure>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<p class="t3-sous-titre"><?php esc_html_e( 'Ajoutez des images à vos chambres pour alimenter la galerie.', 'theme3-hotel' ); ?></p>
			<?php endif; ?>

			<div class="entry-content t3-page-contenu">
				<?php the_content(); ?>
			</div>

		</div>
	</section>

	<?php
endwhile;

get_footer();
