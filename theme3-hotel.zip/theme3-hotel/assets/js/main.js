/**
 * Theme3 Hôtel - Interactions générales.
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var burger = document.querySelector('.t3-burger');
		var nav = document.querySelector('.t3-nav');

		if (burger && nav) {
			burger.addEventListener('click', function () {
				var ouvert = nav.classList.toggle('ouvert');
				burger.classList.toggle('actif', ouvert);
				burger.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
			});
		}

		var principale = document.getElementById('t3-image-principale');
		var miniatures = document.querySelectorAll('.t3-chambre-miniatures img');

		miniatures.forEach(function (miniature) {
			miniature.addEventListener('click', function () {
				if (!principale || !miniature.dataset.grande) {
					return;
				}
				principale.src = miniature.dataset.grande;
				miniatures.forEach(function (autre) {
					autre.classList.remove('active');
				});
				miniature.classList.add('active');
			});
		});
	});
})();
