/**
 * Theme3 Hôtel - Calendrier de disponibilité interactif.
 *
 * Données fournies par T3CalendrierData :
 * { aujourdhui: 'Y-m-d', nbMois: 6, reservations: [{ arrivee: 'Y-m-d', depart: 'Y-m-d' }] }
 */
(function () {
	'use strict';

	var data = window.T3CalendrierData || {};
	var conteneur = document.getElementById('t3-calendrier');

	if (!conteneur) {
		return;
	}

	var MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
	var JOURS = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

	var parties = String(data.aujourdhui || '').split('-');
	var aujourdHui = parties.length === 3
		? new Date(+parties[0], +parties[1] - 1, +parties[2])
		: new Date();

	var nbMois = parseInt(data.nbMois, 10) || 6;
	var reservations = Array.isArray(data.reservations) ? data.reservations : [];
	var courant = new Date(aujourdHui.getFullYear(), aujourdHui.getMonth(), 1);

	var arrivee = null;
	var depart = null;

	function cle(date) {
		var m = String(date.getMonth() + 1);
		var j = String(date.getDate());
		return date.getFullYear() + '-' + (m.length < 2 ? '0' + m : m) + '-' + (j.length < 2 ? '0' + j : j);
	}

	function parseCle(valeur) {
		var p = String(valeur || '').split('-');
		return p.length === 3 ? new Date(+p[0], +p[1] - 1, +p[2]) : null;
	}

	function estIndisponible(date) {
		var k = cle(date);
		for (var i = 0; i < reservations.length; i++) {
			if (k >= reservations[i].arrivee && k < reservations[i].depart) {
				return true;
			}
		}
		return false;
	}

	function plageContientIndisponible(debut, fin) {
		var d = new Date(debut);
		while (d < fin) {
			if (estIndisponible(d)) {
				return true;
			}
			d.setDate(d.getDate() + 1);
		}
		return false;
	}

	function majChamps() {
		var champArrivee = document.getElementById('t3-arrivee');
		var champDepart = document.getElementById('t3-depart');

		if (champArrivee) {
			champArrivee.value = arrivee ? cle(arrivee) : '';
			champArrivee.min = cle(aujourdHui);
		}
		if (champDepart) {
			champDepart.value = depart ? cle(depart) : '';
			champDepart.min = arrivee ? cle(new Date(arrivee.getTime() + 86400000)) : cle(aujourdHui);
		}
	}

	function auClicJour(date) {
		if (!arrivee || (arrivee && depart)) {
			arrivee = date;
			depart = null;
		} else if (date <= arrivee) {
			arrivee = date;
		} else if (plageContientIndisponible(arrivee, date)) {
			arrivee = date;
			depart = null;
		} else {
			depart = date;
		}
		majChamps();
		rendre();
	}

	function rendre() {
		conteneur.innerHTML = '';

		var entete = document.createElement('div');
		entete.className = 't3-calendrier-entete';

		var precedent = document.createElement('button');
		precedent.type = 'button';
		precedent.className = 't3-calendrier-nav';
		precedent.textContent = '\u2039';
		precedent.setAttribute('aria-label', 'Mois précédent');

		var titre = document.createElement('span');
		titre.className = 't3-calendrier-mois';
		titre.textContent = MOIS[courant.getMonth()] + ' ' + courant.getFullYear();

		var suivant = document.createElement('button');
		suivant.type = 'button';
		suivant.className = 't3-calendrier-nav';
		suivant.textContent = '\u203A';
		suivant.setAttribute('aria-label', 'Mois suivant');

		var moisEcoules = (courant.getFullYear() - aujourdHui.getFullYear()) * 12 + (courant.getMonth() - aujourdHui.getMonth());
		precedent.disabled = moisEcoules <= 0;
		suivant.disabled = moisEcoules >= nbMois - 1;

		precedent.addEventListener('click', function () {
			courant.setMonth(courant.getMonth() - 1);
			rendre();
		});
		suivant.addEventListener('click', function () {
			courant.setMonth(courant.getMonth() + 1);
			rendre();
		});

		entete.appendChild(precedent);
		entete.appendChild(titre);
		entete.appendChild(suivant);
		conteneur.appendChild(entete);

		var table = document.createElement('table');
		table.className = 't3-calendrier-table';

		var thead = document.createElement('thead');
		var ligneJours = document.createElement('tr');
		JOURS.forEach(function (jour) {
			var th = document.createElement('th');
			th.textContent = jour;
			ligneJours.appendChild(th);
		});
		thead.appendChild(ligneJours);
		table.appendChild(thead);

		var tbody = document.createElement('tbody');
		var ligne = document.createElement('tr');

		var decalage = (courant.getDay() + 6) % 7;
		for (var v = 0; v < decalage; v++) {
			ligne.appendChild(document.createElement('td'));
		}

		var nbJours = new Date(courant.getFullYear(), courant.getMonth() + 1, 0).getDate();

		for (var jour = 1; jour <= nbJours; jour++) {
			var td = document.createElement('td');
			var date = new Date(courant.getFullYear(), courant.getMonth(), jour);
			var bouton = document.createElement('button');
			var k = cle(date);

			bouton.type = 'button';
			bouton.className = 't3-jour';
			bouton.textContent = jour;

			if (k === cle(aujourdHui)) {
				bouton.style.borderColor = '#c8a24b';
			}

			if (date < aujourdHui) {
				bouton.classList.add('passe');
			} else if (estIndisponible(date)) {
				bouton.classList.add('indisponible');
			} else if (arrivee && depart && date > arrivee && date < depart) {
				bouton.classList.add('dans-plage');
			}

			if (arrivee && k === cle(arrivee)) {
				bouton.classList.add('arrivee');
			}
			if (depart && k === cle(depart)) {
				bouton.classList.add('depart');
			}

			if (!bouton.classList.contains('passe') && !bouton.classList.contains('indisponible')) {
				bouton.addEventListener('click', function (d) {
					return function () {
						auClicJour(d);
					};
				}(date));
			} else {
				bouton.disabled = true;
			}

			td.appendChild(bouton);
			ligne.appendChild(td);

			if ((decalage + jour) % 7 === 0) {
				tbody.appendChild(ligne);
				ligne = document.createElement('tr');
			}
		}

		tbody.appendChild(ligne);
		table.appendChild(tbody);
		conteneur.appendChild(table);
	}

	var initArrivee = parseCle((document.getElementById('t3-arrivee') || {}).value);
	var initDepart = parseCle((document.getElementById('t3-depart') || {}).value);

	if (initArrivee && initArrivee >= aujourdHui) {
		arrivee = initArrivee;
	}
	if (initDepart && initDepart > initArrivee) {
		depart = initDepart;
	}

	majChamps();
	rendre();
})();
