/**
 * Theme3 Hôtel - Lightbox de la galerie photos.
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var items = Array.prototype.slice.call(document.querySelectorAll('.t3-galerie-item img'));

		if (!items.length) {
			return;
		}

		var index = 0;
		var overlay = document.createElement('div');
		overlay.className = 't3-lightbox';
		overlay.setAttribute('role', 'dialog');
		overlay.setAttribute('aria-label', 'Galerie photos');
		overlay.innerHTML =
			'<button class="t3-lightbox-fermer" aria-label="Fermer">&times;</button>' +
			'<button class="t3-lightbox-prev" aria-label="Précédent">&#8249;</button>' +
			'<img src="" alt="">' +
			'<button class="t3-lightbox-next" aria-label="Suivant">&#8250;</button>';
		document.body.appendChild(overlay);

		var image = overlay.querySelector('img');

		function afficher(i) {
			index = (i + items.length) % items.length;
			image.src = items[index].currentSrc || items[index].src;
			overlay.classList.add('ouvert');
		}

		function fermer() {
			overlay.classList.remove('ouvert');
		}

		items.forEach(function (item, i) {
			item.parentElement.addEventListener('click', function (e) {
				e.preventDefault();
				afficher(i);
			});
		});

		overlay.querySelector('.t3-lightbox-fermer').addEventListener('click', fermer);
		overlay.querySelector('.t3-lightbox-prev').addEventListener('click', function () {
			afficher(index - 1);
		});
		overlay.querySelector('.t3-lightbox-next').addEventListener('click', function () {
			afficher(index + 1);
		});

		overlay.addEventListener('click', function (e) {
			if (e.target === overlay) {
				fermer();
			}
		});

		document.addEventListener('keydown', function (e) {
			if (!overlay.classList.contains('ouvert')) {
				return;
			}
			if (e.key === 'Escape') {
				fermer();
			} else if (e.key === 'ArrowLeft') {
				afficher(index - 1);
			} else if (e.key === 'ArrowRight') {
				afficher(index + 1);
			}
		});
	});
})();
