<?php
/**
 * Fiche chambre détaillée : galerie, infos, équipements, calendrier.
 *
 * @package theme3-hotel
 */

get_header();

while ( have_posts() ) :
	the_post();

	$capacite = (int) get_post_meta( get_the_ID(), 't3_capacite', true );
	$surface  = (int) get_post_meta( get_the_ID(), 't3_surface', true );
	$prix     = t3_hotel_prix_formate( get_the_ID() );

	$miniatures = array();
	if ( has_post_thumbnail() ) {
		$miniatures[] = (int) get_post_thumbnail_id();
	}
	foreach ( get_attached_media( 'image', get_the_ID() ) as $media ) {
		if ( count( $miniatures ) >= 4 ) {
			break;
		}
		if ( (int) $media->ID !== (int) get_post_thumbnail_id() ) {
			$miniatures[] = (int) $media->ID;
		}
	}

	$url_dispo = t3_hotel_url_disponibilite();
	if ( $url_dispo ) {
		$url_dispo = add_query_arg( 'chambre', get_the_ID(), $url_dispo );
	}
	?>

	<div class="t3-container">
		<article class="t3-single-chambre">

			<div>
				<div class="t3-chambre-galerie-principale">
					<?php if ( has_post_thumbnail() ) : ?>
						<img id="t3-image-principale" src="<?php echo esc_url( get_the_post_thumbnail_url( get_the_ID(), 'large' ) ); ?>" alt="<?php the_title_attribute(); ?>">
					<?php endif; ?>
				</div>

				<?php if ( count( $miniatures ) > 1 ) : ?>
					<div class="t3-chambre-miniatures">
						<?php foreach ( $miniatures as $index => $image_id ) : ?>
							<img src="<?php echo esc_url( wp_get_attachment_image_url( $image_id, 'medium' ) ); ?>"
								data-grande="<?php echo esc_url( wp_get_attachment_image_url( $image_id, 'large' ) ); ?>"
								class="<?php echo 0 === $index ? 'active' : ''; ?>"
								alt="">
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>

			<div class="t3-chambre-infos">
				<h1><?php the_title(); ?></h1>

				<?php if ( $prix ) : ?>
					<p class="t3-chambre-prix"><?php echo esc_html( $prix ); ?></p>
				<?php endif; ?>

				<p class="t3-carte-meta">
					<?php if ( $capacite ) : ?>
						<span><?php echo esc_html( sprintf( _n( '%d personne', '%d personnes', $capacite, 'theme3-hotel' ), $capacite ) ); ?></span>
					<?php endif; ?>
					<?php if ( $surface ) : ?>
						<span><?php echo esc_html( sprintf( __( '%d m²', 'theme3-hotel' ), $surface ) ); ?></span>
					<?php endif; ?>
				</p>

				<?php
				$equipements = t3_hotel_equipements_chambre();
				if ( $equipements ) :
					?>
					<ul class="t3-equipements">
						<?php foreach ( $equipements as $equipement ) : ?>
							<li><?php echo esc_html( $equipement ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>

				<div class="entry-content">
					<?php the_content(); ?>
				</div>

				<?php if ( $url_dispo ) : ?>
					<a class="t3-btn" href="<?php echo esc_url( $url_dispo ); ?>"><?php esc_html_e( 'Réserver cette chambre', 'theme3-hotel' ); ?></a>
				<?php endif; ?>
			</div>

		</article>
	</div>

	<section class="t3-section t3-section--clair">
		<div class="t3-container">
			<h2 class="t3-titre-section"><?php esc_html_e( 'Disponibilités', 'theme3-hotel' ); ?></h2>
			<p class="t3-sous-titre"><?php esc_html_e( 'Sélectionnez vos dates d\'arrivée et de départ directement sur le calendrier.', 'theme3-hotel' ); ?></p>

			<div class="t3-calendrier" id="t3-calendrier"></div>

			<div class="t3-calendrier-legende">
				<span class="t3-legende-libre"><?php esc_html_e( 'Disponible', 'theme3-hotel' ); ?></span>
				<span class="t3-legende-occupe"><?php esc_html_e( 'Indisponible', 'theme3-hotel' ); ?></span>
				<span class="t3-legende-selection"><?php esc_html_e( 'Votre sélection', 'theme3-hotel' ); ?></span>
			</div>
		</div>
	</section>

	<?php
endwhile;

get_footer();
