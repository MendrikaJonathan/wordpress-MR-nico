<?php
/**
 * Formulaire de recherche.
 *
 * @package theme3-hotel
 */
?>
<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="t3-champ-recherche"><?php esc_html_e( 'Rechercher', 'theme3-hotel' ); ?></label>
	<input type="search" id="t3-champ-recherche" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Rechercher…', 'theme3-hotel' ); ?>">
	<button type="submit" aria-label="<?php esc_attr_e( 'Lancer la recherche', 'theme3-hotel' ); ?>">
		<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>
	</button>
</form>
