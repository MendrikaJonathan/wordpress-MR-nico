<?php
/**
 * Pied de page du thème.
 *
 * @package theme3-hotel
 */
?>
</main>

<footer class="t3-footer">
	<div class="t3-container">
		<div class="t3-footer-grid">

			<div>
				<h4><?php bloginfo( 'name' ); ?></h4>
				<p style="font-size:.92rem;"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
			</div>

			<div>
				<h4><?php esc_html_e( 'Navigation', 'theme3-hotel' ); ?></h4>
				<?php
				if ( has_nav_menu( 'footer' ) ) {
					wp_nav_menu(
						array(
							'theme_location' => 'footer',
							'container'      => false,
							'menu_class'     => '',
							'depth'          => 1,
						)
					);
				} else {
					echo '<ul>';
					wp_list_pages( array( 'title_li' => '', 'depth' => 1 ) );
					echo '</ul>';
				}
				?>
			</div>

			<div>
				<h4><?php esc_html_e( 'Votre séjour', 'theme3-hotel' ); ?></h4>
				<ul>
					<li><a href="<?php echo esc_url( get_post_type_archive_link( 'chambre' ) ); ?>"><?php esc_html_e( 'Nos chambres', 'theme3-hotel' ); ?></a></li>
					<?php if ( t3_hotel_url_disponibilite() ) : ?>
						<li><a href="<?php echo esc_url( t3_hotel_url_disponibilite() ); ?>"><?php esc_html_e( 'Disponibilités & réservation', 'theme3-hotel' ); ?></a></li>
					<?php endif; ?>
					<?php if ( t3_hotel_url_galerie() ) : ?>
						<li><a href="<?php echo esc_url( t3_hotel_url_galerie() ); ?>"><?php esc_html_e( 'Galerie photos', 'theme3-hotel' ); ?></a></li>
					<?php endif; ?>
					<?php if ( t3_hotel_url_temoignages() ) : ?>
						<li><a href="<?php echo esc_url( t3_hotel_url_temoignages() ); ?>"><?php esc_html_e( 'Avis clients', 'theme3-hotel' ); ?></a></li>
					<?php endif; ?>
				</ul>
			</div>

		</div>

		<div class="t3-footer-bas">
			&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?> — <?php esc_html_e( 'Tous droits réservés', 'theme3-hotel' ); ?>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
