<?php
/**
 * Page d'accueil : hero, recherche rapide, chambres, galerie, témoignages.
 *
 * @package theme3-hotel
 */

get_header();

$page_id = get_queried_object_id();
$titre   = $page_id && get_the_title( $page_id ) ? get_the_title( $page_id ) : get_bloginfo( 'name' );
$sous_titre = $page_id && has_excerpt( $page_id ) ? get_the_excerpt( $page_id ) : get_bloginfo( 'description' );

$image_hero = '';
if ( $page_id && has_post_thumbnail( $page_id ) ) {
	$image_hero = get_the_post_thumbnail_url( $page_id, 'full' );
} else {
	$chambres_hero = get_posts(
		array(
			'post_type'      => 'chambre',
			'posts_per_page' => 1,
			'no_found_rows'  => true,
			'meta_key'       => '_thumbnail_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		)
	);
	if ( ! empty( $chambres_hero ) ) {
		$image_hero = get_the_post_thumbnail_url( $chambres_hero[0], 'full' );
	}
}
?>

<section class="t3-hero" <?php if ( $image_hero ) : ?>style="background-image:url('<?php echo esc_url( $image_hero ); ?>');"<?php endif; ?>>
	<div class="t3-hero-contenu">
		<h1><?php echo esc_html( $titre ); ?></h1>
		<p><?php echo esc_html( $sous_titre ); ?></p>
		<div class="t3-hero-actions">
			<a class="t3-btn" href="<?php echo esc_url( get_post_type_archive_link( 'chambre' ) ); ?>"><?php esc_html_e( 'Découvrir nos chambres', 'theme3-hotel' ); ?></a>
			<?php if ( t3_hotel_url_disponibilite() ) : ?>
				<a class="t3-btn t3-btn--contour" href="<?php echo esc_url( t3_hotel_url_disponibilite() ); ?>"><?php esc_html_e( 'Vérifier les disponibilités', 'theme3-hotel' ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</section>

<div class="t3-container">
	<?php get_template_part( 'template-parts/barre-recherche' ); ?>
</div>

<?php
$chambres = new WP_Query(
	array(
		'post_type'      => 'chambre',
		'posts_per_page' => 6,
		'no_found_rows'  => true,
	)
);

if ( $chambres->have_posts() ) :
	?>
	<section class="t3-section">
		<div class="t3-container">
			<h2 class="t3-titre-section"><?php esc_html_e( 'Nos chambres', 'theme3-hotel' ); ?></h2>
			<p class="t3-sous-titre"><?php esc_html_e( 'Confort, élégance et vue exceptionnelle pour un séjour inoubliable.', 'theme3-hotel' ); ?></p>

			<div class="t3-grille">
				<?php
				while ( $chambres->have_posts() ) :
					$chambres->the_post();
					get_template_part( 'template-parts/carte-chambre' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>

			<p style="text-align:center;margin-top:40px;">
				<a class="t3-btn t3-btn--contour" href="<?php echo esc_url( get_post_type_archive_link( 'chambre' ) ); ?>"><?php esc_html_e( 'Voir toutes les chambres', 'theme3-hotel' ); ?></a>
			</p>
		</div>
	</section>
<?php endif; ?>

<?php
$images_galerie = t3_hotel_images_galerie( 8 );

if ( $images_galerie ) :
	?>
	<section class="t3-section t3-section--clair">
		<div class="t3-container">
			<h2 class="t3-titre-section"><?php esc_html_e( 'Galerie', 'theme3-hotel' ); ?></h2>
			<p class="t3-sous-titre"><?php esc_html_e( 'Un aperçu de notre univers.', 'theme3-hotel' ); ?></p>

			<div class="t3-galerie">
				<?php foreach ( $images_galerie as $image_id ) : ?>
					<figure class="t3-galerie-item">
						<?php echo wp_get_attachment_image( $image_id, 't3-galerie' ); ?>
					</figure>
				<?php endforeach; ?>
			</div>

			<?php if ( t3_hotel_url_galerie() ) : ?>
				<p style="text-align:center;margin-top:40px;">
					<a class="t3-btn t3-btn--contour" href="<?php echo esc_url( t3_hotel_url_galerie() ); ?>"><?php esc_html_e( 'Toute la galerie', 'theme3-hotel' ); ?></a>
				</p>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>

<?php
$temoignages = new WP_Query(
	array(
		'post_type'      => 'temoignage',
		'posts_per_page' => 3,
		'no_found_rows'  => true,
	)
);

if ( $temoignages->have_posts() ) :
	?>
	<section class="t3-section">
		<div class="t3-container">
			<h2 class="t3-titre-section"><?php esc_html_e( 'Ils ont séjourné chez nous', 'theme3-hotel' ); ?></h2>
			<p class="t3-sous-titre"><?php esc_html_e( 'Les avis de nos clients.', 'theme3-hotel' ); ?></p>

			<div class="t3-grille">
				<?php
				while ( $temoignages->have_posts() ) :
					$temoignages->the_post();
					get_template_part( 'template-parts/temoignage' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>

			<?php if ( t3_hotel_url_temoignages() ) : ?>
				<p style="text-align:center;margin-top:40px;">
					<a class="t3-btn t3-btn--contour" href="<?php echo esc_url( t3_hotel_url_temoignages() ); ?>"><?php esc_html_e( 'Tous les témoignages', 'theme3-hotel' ); ?></a>
				</p>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>

<section class="t3-section t3-section--clair">
	<div class="t3-container" style="text-align:center;">
		<h2 class="t3-titre-section"><?php esc_html_e( 'Prêt à réserver ?', 'theme3-hotel' ); ?></h2>
		<p class="t3-sous-titre"><?php esc_html_e( 'Consultez le calendrier et réservez votre chambre en quelques clics.', 'theme3-hotel' ); ?></p>
		<?php if ( t3_hotel_url_disponibilite() ) : ?>
			<a class="t3-btn" href="<?php echo esc_url( t3_hotel_url_disponibilite() ); ?>"><?php esc_html_e( 'Réserver maintenant', 'theme3-hotel' ); ?></a>
		<?php endif; ?>
	</div>
</section>

<?php get_footer(); ?>
