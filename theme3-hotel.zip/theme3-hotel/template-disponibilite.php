<?php
/**
 * Page disponibilité : calendrier interactif + formulaire de réservation.
 *
 * @package theme3-hotel
 */

get_header();

$arrivee   = isset( $_GET['arrivee'] ) ? sanitize_text_field( wp_unslash( $_GET['arrivee'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$depart    = isset( $_GET['depart'] ) ? sanitize_text_field( wp_unslash( $_GET['depart'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$personnes = isset( $_GET['personnes'] ) ? absint( $_GET['personnes'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$chambre   = isset( $_GET['chambre'] ) ? absint( $_GET['chambre'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$chambres = get_posts(
	array(
		'post_type'      => 'chambre',
		'posts_per_page' => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
	)
);
?>

<section class="t3-section">
	<div class="t3-container">

		<h1 class="t3-titre-section"><?php esc_html_e( 'Disponibilités & réservation', 'theme3-hotel' ); ?></h1>
		<p class="t3-sous-titre"><?php esc_html_e( 'Sélectionnez vos dates sur le calendrier puis complétez le formulaire.', 'theme3-hotel' ); ?></p>

		<?php if ( isset( $_GET['reservation'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<?php if ( 'succes' === sanitize_key( wp_unslash( $_GET['reservation'] ) ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="t3-message t3-message--ok"><?php esc_html_e( 'Votre demande de réservation a bien été enregistrée. Nous vous confirmerons par email dans les plus brefs délais.', 'theme3-hotel' ); ?></div>
			<?php else : ?>
				<div class="t3-message t3-message--erreur">
					<?php
					$raison = isset( $_GET['raison'] ) ? sanitize_key( wp_unslash( $_GET['raison'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					if ( 'indisponible' === $raison ) {
						esc_html_e( 'Cette chambre est déjà réservée sur ces dates. Merci de choisir une autre période.', 'theme3-hotel' );
					} elseif ( 'validation' === $raison ) {
						esc_html_e( 'Merci de vérifier les champs du formulaire (dates, chambre, nom et email valides).', 'theme3-hotel' );
					} else {
						esc_html_e( 'Une erreur est survenue lors de l\'envoi. Merci de réessayer.', 'theme3-hotel' );
					}
					?>
				</div>
			<?php endif; ?>
		<?php endif; ?>

		<div class="t3-calendrier-wrap">

			<div>
				<div class="t3-calendrier" id="t3-calendrier"></div>

				<div class="t3-calendrier-legende">
					<span class="t3-legende-libre"><?php esc_html_e( 'Disponible', 'theme3-hotel' ); ?></span>
					<span class="t3-legende-occupe"><?php esc_html_e( 'Indisponible', 'theme3-hotel' ); ?></span>
					<span class="t3-legende-selection"><?php esc_html_e( 'Votre sélection', 'theme3-hotel' ); ?></span>
				</div>
			</div>

			<div class="t3-reservation-form">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="t3_reservation">
					<?php wp_nonce_field( 't3_reservation', 't3_reservation_nonce' ); ?>

					<div class="t3-champ">
						<label for="t3-chambre"><?php esc_html_e( 'Chambre', 'theme3-hotel' ); ?></label>
						<select id="t3-chambre" name="t3_chambre" required>
							<option value=""><?php esc_html_e( '— Choisir —', 'theme3-hotel' ); ?></option>
							<?php foreach ( $chambres as $chambre_post ) : ?>
								<option value="<?php echo esc_attr( $chambre_post->ID ); ?>" <?php selected( $chambre, $chambre_post->ID ); ?>><?php echo esc_html( $chambre_post->post_title ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="t3-ligne-2">
						<div class="t3-champ">
							<label for="t3-arrivee"><?php esc_html_e( 'Arrivée', 'theme3-hotel' ); ?></label>
							<input type="date" id="t3-arrivee" name="t3_arrivee" value="<?php echo esc_attr( $arrivee ); ?>" required>
						</div>
						<div class="t3-champ">
							<label for="t3-depart"><?php esc_html_e( 'Départ', 'theme3-hotel' ); ?></label>
							<input type="date" id="t3-depart" name="t3_depart" value="<?php echo esc_attr( $depart ); ?>" required>
						</div>
					</div>

					<div class="t3-champ">
						<label for="t3-personnes"><?php esc_html_e( 'Nombre de personnes', 'theme3-hotel' ); ?></label>
						<input type="number" id="t3-personnes" name="t3_personnes" min="1" max="10" value="<?php echo esc_attr( $personnes > 0 ? $personnes : 2 ); ?>" required>
					</div>

					<div class="t3-ligne-2">
						<div class="t3-champ">
							<label for="t3-nom"><?php esc_html_e( 'Nom complet', 'theme3-hotel' ); ?></label>
							<input type="text" id="t3-nom" name="t3_nom" required>
						</div>
						<div class="t3-champ">
							<label for="t3-email"><?php esc_html_e( 'Email', 'theme3-hotel' ); ?></label>
							<input type="email" id="t3-email" name="t3_email" required>
						</div>
					</div>

					<div class="t3-champ">
						<label for="t3-telephone"><?php esc_html_e( 'Téléphone (facultatif)', 'theme3-hotel' ); ?></label>
						<input type="tel" id="t3-telephone" name="t3_telephone">
					</div>

					<div class="t3-champ">
						<label for="t3-message"><?php esc_html_e( 'Message (facultatif)', 'theme3-hotel' ); ?></label>
						<textarea id="t3-message" name="t3_message" rows="4"></textarea>
					</div>

					<button type="submit" class="t3-btn t3-btn--bloque"><?php esc_html_e( 'Envoyer la demande', 'theme3-hotel' ); ?></button>
				</form>
			</div>

		</div>

	</div>
</section>

<?php get_footer(); ?>
