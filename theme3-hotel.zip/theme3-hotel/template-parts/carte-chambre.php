<?php
/**
 * Carte chambre réutilisée dans les grilles.
 *
 * @package theme3-hotel
 */

$prix = t3_hotel_prix_formate( get_the_ID() );
$capacite = (int) get_post_meta( get_the_ID(), 't3_capacite', true );
$surface  = (int) get_post_meta( get_the_ID(), 't3_surface', true );
?>

<article <?php post_class( 't3-carte' ); ?>>

	<a class="t3-carte-image" href="<?php the_permalink(); ?>">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 't3-chambre' ); ?>
		<?php endif; ?>
		<?php if ( $prix ) : ?>
			<span class="t3-carte-prix"><?php echo esc_html( $prix ); ?></span>
		<?php endif; ?>
	</a>

	<div class="t3-carte-corps">
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

		<p class="t3-carte-meta">
			<?php if ( $capacite ) : ?>
				<span><?php echo esc_html( sprintf( _n( '%d personne', '%d personnes', $capacite, 'theme3-hotel' ), $capacite ) ); ?></span>
			<?php endif; ?>
			<?php if ( $surface ) : ?>
				<span><?php echo esc_html( sprintf( __( '%d m²', 'theme3-hotel' ), $surface ) ); ?></span>
			<?php endif; ?>
		</p>

		<p class="t3-carte-extrait"><?php echo esc_html( get_the_excerpt() ); ?></p>

		<a class="t3-btn" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Voir la chambre', 'theme3-hotel' ); ?></a>
	</div>

</article>
