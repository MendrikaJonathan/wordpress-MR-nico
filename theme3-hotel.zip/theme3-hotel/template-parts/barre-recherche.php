<?php
/**
 * Barre de recherche de séjour (réservation rapide).
 *
 * @package theme3-hotel
 */

$url_dispo = t3_hotel_url_disponibilite();

if ( ! $url_dispo ) {
	return;
}
?>

<div class="t3-barre-recherche">
	<form method="get" action="<?php echo esc_url( $url_dispo ); ?>">
		<div class="t3-champ">
			<label for="t3-br-arrivee"><?php esc_html_e( 'Arrivée', 'theme3-hotel' ); ?></label>
			<input type="date" id="t3-br-arrivee" name="arrivee">
		</div>

		<div class="t3-champ">
			<label for="t3-br-depart"><?php esc_html_e( 'Départ', 'theme3-hotel' ); ?></label>
			<input type="date" id="t3-br-depart" name="depart">
		</div>

		<div class="t3-champ">
			<label for="t3-br-personnes"><?php esc_html_e( 'Personnes', 'theme3-hotel' ); ?></label>
			<select id="t3-br-personnes" name="personnes">
				<?php for ( $i = 1; $i <= 6; $i++ ) : ?>
					<option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_html( $i ); ?></option>
				<?php endfor; ?>
			</select>
		</div>

		<button type="submit" class="t3-btn"><?php esc_html_e( 'Vérifier', 'theme3-hotel' ); ?></button>
	</form>
</div>
