<?php
/**
 * Carte témoignage réutilisée dans les grilles.
 *
 * @package theme3-hotel
 */

$note   = get_post_meta( get_the_ID(), 't3_note', true );
$sejour = get_post_meta( get_the_ID(), 't3_chambre_sejournee', true );
?>

<article <?php post_class( 't3-temoignage' ); ?>>

	<?php if ( $note ) : ?>
		<?php t3_hotel_etoiles( $note ); ?>
	<?php endif; ?>

	<p class="t3-temoignage-texte"><?php echo esc_html( get_the_excerpt() ? get_the_excerpt() : wp_strip_all_tags( get_the_content() ) ); ?></p>

	<div class="t3-temoignage-pied">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php echo wp_get_attachment_image( get_post_thumbnail_id(), 'thumbnail', false, array( 'class' => 't3-temoignage-avatar' ) ); ?>
		<?php endif; ?>
		<div>
			<span class="t3-temoignage-nom"><?php the_title(); ?></span><br>
			<?php if ( $sejour ) : ?>
				<span class="t3-temoignage-chambre"><?php echo esc_html( $sejour ); ?></span>
			<?php endif; ?>
		</div>
	</div>

</article>
