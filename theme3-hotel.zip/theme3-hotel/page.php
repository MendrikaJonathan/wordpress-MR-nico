<?php
/**
 * Page générique.
 *
 * @package theme3-hotel
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<section class="t3-section">
		<div class="t3-container t3-page-contenu">

			<header class="t3-entry-header">
				<h1><?php the_title(); ?></h1>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<figure style="margin:0 0 30px;">
					<?php the_post_thumbnail( 'large', array( 'style' => 'border-radius:10px;' ) ); ?>
				</figure>
			<?php endif; ?>

			<div class="entry-content">
				<?php the_content(); ?>
			</div>

		</div>
	</section>

	<?php
endwhile;

get_footer();
