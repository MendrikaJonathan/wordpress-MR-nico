<?php
/**
 * Theme3 Hôtel - Fonctions du thème.
 *
 * @package theme3-hotel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'T3_HOTEL_VERSION', '1.0.0' );

require_once get_template_directory() . '/inc/post-types.php';
require_once get_template_directory() . '/inc/meta-boxes.php';
require_once get_template_directory() . '/inc/reservations.php';
require_once get_template_directory() . '/inc/helpers.php';

/**
 * Configuration du thème.
 */
function t3_hotel_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);

	register_nav_menus(
		array(
			'primary' => __( 'Menu principal', 'theme3-hotel' ),
			'footer'  => __( 'Menu pied de page', 'theme3-hotel' ),
		)
	);

	add_image_size( 't3-chambre', 800, 600, true );
	add_image_size( 't3-galerie', 700, 900, false );
}
add_action( 'after_setup_theme', 't3_hotel_setup' );

/**
 * Scripts et styles.
 */
function t3_hotel_scripts() {
	wp_enqueue_style(
		't3-google-fonts',
		'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:wght@400;600;700&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 't3-style', get_stylesheet_uri(), array(), T3_HOTEL_VERSION );
	wp_enqueue_script( 't3-main', get_template_directory_uri() . '/assets/js/main.js', array(), T3_HOTEL_VERSION, true );

	if ( is_singular( 'chambre' ) || is_page_template( 'template-disponibilite.php' ) ) {
		wp_enqueue_script( 't3-calendrier', get_template_directory_uri() . '/assets/js/calendrier.js', array(), T3_HOTEL_VERSION, true );
		wp_localize_script( 't3-calendrier', 'T3CalendrierData', t3_hotel_donnees_calendrier() );
	}

	if ( is_page_template( 'template-galerie.php' ) || is_post_type_archive( 'chambre' ) ) {
		wp_enqueue_script( 't3-galerie', get_template_directory_uri() . '/assets/js/galerie.js', array(), T3_HOTEL_VERSION, true );
	}
}
add_action( 'wp_enqueue_scripts', 't3_hotel_scripts' );

/**
 * Construit les données de disponibilité transmises au calendrier JS.
 *
 * @return array { mois: [ [date => statut] ], reservations: [...] }
 */
function t3_hotel_donnees_calendrier() {
	$chambre_id = 0;

	if ( is_singular( 'chambre' ) ) {
		$chambre_id = get_queried_object_id();
	}

	$reservations = t3_hotel_reservations_chambre( $chambre_id );

	return array(
		'aujourdhui'   => current_time( 'Y-m-d' ),
		'nbMois'       => 6,
		'reservations' => $reservations,
	);
}

/**
 * Longueur des extraits.
 *
 * @param int $longueur Longueur par défaut.
 * @return int
 */
function t3_hotel_extrait_longueur( $longueur ) {
	return 22;
}
add_filter( 'excerpt_length', 't3_hotel_extrait_longueur' );

/**
 * Suffixe des extraits.
 *
 * @param string $more Suffixe par défaut.
 * @return string
 */
function t3_hotel_extrait_suite( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 't3_hotel_extrait_suite' );

/**
 * Inclut les chambres dans les résultats de recherche.
 *
 * @param WP_Query $query Requête principale.
 */
function t3_hotel_recherche_chambres( $query ) {
	if ( $query->is_main_query() && $query->is_search() && ! is_admin() ) {
		$query->set( 'post_type', array( 'post', 'page', 'chambre' ) );
	}
}
add_action( 'pre_get_posts', 't3_hotel_recherche_chambres' );

/**
 * Filtre l'archive des chambres : capacité minimum passée en GET.
 *
 * @param WP_Query $query Requête principale.
 */
function t3_hotel_filtre_archive_chambres( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}

	if ( $query->is_post_type_archive( 'chambre' ) ) {
		$personnes = isset( $_GET['personnes'] ) ? absint( $_GET['personnes'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( $personnes > 0 ) {
			$meta_query = array(
				array(
					'key'     => 't3_capacite',
					'value'   => $personnes,
					'type'    => 'NUMERIC',
					'compare' => '>=',
				),
			);
			$query->set( 'meta_query', $meta_query );
		}

		$prix_max = isset( $_GET['prix_max'] ) ? absint( $_GET['prix_max'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( $prix_max > 0 ) {
			$meta_query   = (array) $query->get( 'meta_query' );
			$meta_query[] = array(
				'key'     => 't3_prix',
				'value'   => $prix_max,
				'type'    => 'NUMERIC',
				'compare' => '<=',
			);
			$query->set( 'meta_query', $meta_query );
		}
	}
}
add_action( 'pre_get_posts', 't3_hotel_filtre_archive_chambres' );

/**
 * Affiche une note en étoiles.
 *
 * @param int $note Note de 1 à 5.
 */
function t3_hotel_etoiles( $note ) {
	$note = max( 1, min( 5, (int) $note ) );
	echo '<span class="t3-etoiles" aria-label="' . esc_attr( $note ) . '/5">';
	echo esc_html( str_repeat( '★', $note ) . str_repeat( '☆', 5 - $note ) );
	echo '</span>';
}

/**
 * Prix formaté d'une chambre.
 *
 * @param int $chambre_id ID de la chambre.
 * @return string
 */
function t3_hotel_prix_formate( $chambre_id = 0 ) {
	$chambre_id = $chambre_id ? $chambre_id : get_the_ID();
	$prix       = get_post_meta( $chambre_id, 't3_prix', true );

	if ( '' === $prix ) {
		return '';
	}
	/* translators: %s : prix par nuit. */
	return sprintf( __( '%s € / nuit', 'theme3-hotel' ), number_format_i18n( (float) $prix, 0 ) );
}
