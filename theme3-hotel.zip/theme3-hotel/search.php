<?php
/**
 * Résultats de recherche.
 *
 * @package theme3-hotel
 */

get_header();
?>

<section class="t3-section">
	<div class="t3-container">

		<h1 class="t3-titre-section">
			<?php
			/* translators: %s : terme recherché. */
			printf( esc_html__( 'Résultats pour « %s »', 'theme3-hotel' ), esc_html( get_search_query() ) );
			?>
		</h1>

		<?php if ( have_posts() ) : ?>
			<div class="t3-grille" style="margin-top:40px;">
				<?php
				while ( have_posts() ) :
					the_post();

					if ( 'chambre' === get_post_type() ) {
						get_template_part( 'template-parts/carte-chambre' );
					} else {
						?>
						<article <?php post_class( 't3-carte' ); ?>>
							<?php if ( has_post_thumbnail() ) : ?>
								<a class="t3-carte-image" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 't3-chambre' ); ?></a>
							<?php endif; ?>
							<div class="t3-carte-corps">
								<span class="t3-carte-meta"><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ); ?></span>
								<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<p class="t3-carte-extrait"><?php echo esc_html( get_the_excerpt() ); ?></p>
								<a class="t3-btn t3-btn--contour" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Voir', 'theme3-hotel' ); ?></a>
							</div>
						</article>
						<?php
					}
				endwhile;
				?>
			</div>

			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 2,
					'class'     => 't3-pagination',
					'prev_text' => __( '&laquo;', 'theme3-hotel' ),
					'next_text' => __( '&raquo;', 'theme3-hotel' ),
				)
			);
			?>

		<?php else : ?>
			<p class="t3-sous-titre"><?php esc_html_e( 'Aucun résultat. Essayez un autre mot-clé.', 'theme3-hotel' ); ?></p>
			<div style="max-width:420px;margin:30px auto;">
				<?php get_search_form(); ?>
			</div>
		<?php endif; ?>

	</div>
</section>

<?php get_footer(); ?>
