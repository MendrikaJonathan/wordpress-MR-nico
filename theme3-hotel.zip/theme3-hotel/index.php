<?php
/**
 * Modèle par défaut (liste d'articles).
 *
 * @package theme3-hotel
 */

get_header();
?>

<section class="t3-section">
	<div class="t3-container">

		<h1 class="t3-titre-section"><?php echo is_home() ? esc_html__( 'Actualités', 'theme3-hotel' ) : esc_html( get_the_archive_title() ); ?></h1>

		<?php if ( have_posts() ) : ?>
			<div class="t3-grille" style="margin-top:40px;">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article <?php post_class( 't3-carte' ); ?>>
						<?php if ( has_post_thumbnail() ) : ?>
							<a class="t3-carte-image" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 't3-chambre' ); ?></a>
						<?php endif; ?>
						<div class="t3-carte-corps">
							<span class="t3-carte-meta"><?php echo esc_html( get_the_date() ); ?></span>
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<p class="t3-carte-extrait"><?php echo esc_html( get_the_excerpt() ); ?></p>
							<a class="t3-btn t3-btn--contour" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Lire la suite', 'theme3-hotel' ); ?></a>
						</div>
					</article>
					<?php
				endwhile;
				?>
			</div>

			<?php
			the_posts_pagination(
				array(
					'mid_size' => 2,
					'class'    => 't3-pagination',
					'prev_text' => __( '&laquo;', 'theme3-hotel' ),
					'next_text' => __( '&raquo;', 'theme3-hotel' ),
				)
			);
			?>

		<?php else : ?>
			<p class="t3-sous-titre"><?php esc_html_e( 'Aucun contenu trouvé.', 'theme3-hotel' ); ?></p>
		<?php endif; ?>

	</div>
</section>

<?php get_footer(); ?>
