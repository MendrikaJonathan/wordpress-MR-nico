<?php
/**
 * Theme3 Hôtel - Types de contenus personnalisés.
 *
 * @package theme3-hotel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enregistre les types de contenus chambre et témoignage.
 */
function t3_hotel_register_post_types() {
	register_post_type(
		'chambre',
		array(
			'labels'        => array(
				'name'               => __( 'Chambres', 'theme3-hotel' ),
				'singular_name'      => __( 'Chambre', 'theme3-hotel' ),
				'menu_name'          => __( 'Chambres', 'theme3-hotel' ),
				'add_new_item'       => __( 'Ajouter une chambre', 'theme3-hotel' ),
				'edit_item'          => __( 'Modifier la chambre', 'theme3-hotel' ),
				'new_item'           => __( 'Nouvelle chambre', 'theme3-hotel' ),
				'view_item'          => __( 'Voir la chambre', 'theme3-hotel' ),
				'search_items'       => __( 'Rechercher des chambres', 'theme3-hotel' ),
				'not_found'          => __( 'Aucune chambre trouvée', 'theme3-hotel' ),
				'all_items'          => __( 'Toutes les chambres', 'theme3-hotel' ),
			),
			'public'        => true,
			'has_archive'   => true,
			'menu_icon'     => 'dashicons-admin-home',
			'rewrite'       => array(
				'slug'       => 'chambres',
				'with_front' => false,
			),
			'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
			'show_in_rest'  => true,
		)
	);

	register_post_type(
		'temoignage',
		array(
			'labels'             => array(
				'name'          => __( 'Témoignages', 'theme3-hotel' ),
				'singular_name' => __( 'Témoignage', 'theme3-hotel' ),
				'menu_name'     => __( 'Témoignages', 'theme3-hotel' ),
				'add_new_item'  => __( 'Ajouter un témoignage', 'theme3-hotel' ),
				'edit_item'     => __( 'Modifier le témoignage', 'theme3-hotel' ),
				'not_found'     => __( 'Aucun témoignage trouvé', 'theme3-hotel' ),
				'all_items'     => __( 'Tous les témoignages', 'theme3-hotel' ),
			),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'menu_icon'          => 'dashicons-format-quote',
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
			'show_in_rest'       => true,
		)
	);
}
add_action( 'init', 't3_hotel_register_post_types' );
