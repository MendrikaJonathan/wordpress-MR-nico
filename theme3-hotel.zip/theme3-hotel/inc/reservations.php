<?php
/**
 * Theme3 Hôtel - Réservations et calendrier de disponibilité.
 *
 * @package theme3-hotel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enregistre le type de contenu réservation.
 */
function t3_hotel_register_reservation() {
	register_post_type(
		'reservation',
		array(
			'labels'             => array(
				'name'          => __( 'Réservations', 'theme3-hotel' ),
				'singular_name' => __( 'Réservation', 'theme3-hotel' ),
				'menu_name'     => __( 'Réservations', 'theme3-hotel' ),
			),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'menu_icon'          => 'dashicons-calendar-alt',
			'supports'           => array( 'title' ),
		)
	);
}
add_action( 'init', 't3_hotel_register_reservation' );

/**
 * Boîte méta réservation.
 */
function t3_hotel_reservation_meta_boxes() {
	add_meta_box( 't3-reservation-details', __( 'Détails de la réservation', 'theme3-hotel' ), 't3_hotel_reservation_meta_box', 'reservation', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 't3_hotel_reservation_meta_boxes' );

/**
 * Contenu de la boîte méta réservation.
 *
 * @param WP_Post $post Objet courant.
 */
function t3_hotel_reservation_meta_box( $post ) {
	wp_nonce_field( 't3_reservation_admin', 't3_reservation_admin_nonce' );

	$arrivee    = get_post_meta( $post->ID, 't3_reservation_arrivee', true );
	$depart     = get_post_meta( $post->ID, 't3_reservation_depart', true );
	$chambre_id = (int) get_post_meta( $post->ID, 't3_reservation_chambre', true );
	$personnes  = get_post_meta( $post->ID, 't3_reservation_personnes', true );
	$telephone  = get_post_meta( $post->ID, 't3_reservation_telephone', true );
	?>
	<p>
		<label for="t3_reservation_chambre"><strong><?php esc_html_e( 'Chambre', 'theme3-hotel' ); ?></strong></label><br />
		<select id="t3_reservation_chambre" name="t3_reservation_chambre">
			<option value=""><?php esc_html_e( '— Aucune —', 'theme3-hotel' ); ?></option>
			<?php foreach ( get_posts( array( 'post_type' => 'chambre', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ) as $chambre ) : ?>
				<option value="<?php echo esc_attr( $chambre->ID ); ?>" <?php selected( $chambre_id, $chambre->ID ); ?>><?php echo esc_html( $chambre->post_title ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<p>
		<label for="t3_reservation_arrivee"><strong><?php esc_html_e( 'Date d\'arrivée', 'theme3-hotel' ); ?></strong></label><br />
		<input type="date" id="t3_reservation_arrivee" name="t3_reservation_arrivee" value="<?php echo esc_attr( $arrivee ); ?>" />
	</p>
	<p>
		<label for="t3_reservation_depart"><strong><?php esc_html_e( 'Date de départ', 'theme3-hotel' ); ?></strong></label><br />
		<input type="date" id="t3_reservation_depart" name="t3_reservation_depart" value="<?php echo esc_attr( $depart ); ?>" />
	</p>
	<p>
		<label for="t3_reservation_personnes"><strong><?php esc_html_e( 'Nombre de personnes', 'theme3-hotel' ); ?></strong></label><br />
		<input type="number" min="1" id="t3_reservation_personnes" name="t3_reservation_personnes" value="<?php echo esc_attr( $personnes ); ?>" />
	</p>
	<p>
		<label for="t3_reservation_telephone"><strong><?php esc_html_e( 'Téléphone', 'theme3-hotel' ); ?></strong></label><br />
		<input type="text" id="t3_reservation_telephone" name="t3_reservation_telephone" value="<?php echo esc_attr( $telephone ); ?>" />
	</p>
	<?php
}

/**
 * Sauvegarde de la boîte méta réservation.
 *
 * @param int $post_id ID du contenu.
 */
function t3_hotel_save_reservation_meta( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE || ! current_user_can( 'edit_post', $post_id ) || get_post_type( $post_id ) !== 'reservation' ) {
		return;
	}

	if ( ! isset( $_POST['t3_reservation_admin_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['t3_reservation_admin_nonce'] ), 't3_reservation_admin' ) ) {
		return;
	}

	update_post_meta( $post_id, 't3_reservation_arrivee', isset( $_POST['t3_reservation_arrivee'] ) ? sanitize_text_field( wp_unslash( $_POST['t3_reservation_arrivee'] ) ) : '' );
	update_post_meta( $post_id, 't3_reservation_depart', isset( $_POST['t3_reservation_depart'] ) ? sanitize_text_field( wp_unslash( $_POST['t3_reservation_depart'] ) ) : '' );
	update_post_meta( $post_id, 't3_reservation_chambre', isset( $_POST['t3_reservation_chambre'] ) ? absint( $_POST['t3_reservation_chambre'] ) : '' );
	update_post_meta( $post_id, 't3_reservation_personnes', isset( $_POST['t3_reservation_personnes'] ) ? absint( $_POST['t3_reservation_personnes'] ) : '' );
	update_post_meta( $post_id, 't3_reservation_telephone', isset( $_POST['t3_reservation_telephone'] ) ? sanitize_text_field( wp_unslash( $_POST['t3_reservation_telephone'] ) ) : '' );
}
add_action( 'save_post', 't3_hotel_save_reservation_meta' );

/**
 * Colonnes personnalisées dans l'administration des réservations.
 *
 * @param array $colonnes Colonnes existantes.
 * @return array
 */
function t3_hotel_reservation_colonnes( $colonnes ) {
	$nouvelles = array(
		'cb'         => $colonnes['cb'],
		'title'      => __( 'Client', 'theme3-hotel' ),
		'chambre'    => __( 'Chambre', 'theme3-hotel' ),
		'dates'      => __( 'Dates', 'theme3-hotel' ),
		'personnes'  => __( 'Personnes', 'theme3-hotel' ),
	);

	return $nouvelles;
}
add_filter( 'manage_reservation_posts_columns', 't3_hotel_reservation_colonnes' );

/**
 * Contenu des colonnes personnalisées.
 *
 * @param string $colonne Colonne courante.
 * @param int    $post_id ID du contenu.
 */
function t3_hotel_reservation_colonne_contenu( $colonne, $post_id ) {
	if ( 'chambre' === $colonne ) {
		$chambre_id = (int) get_post_meta( $post_id, 't3_reservation_chambre', true );
		echo $chambre_id ? esc_html( get_the_title( $chambre_id ) ) : '—';
	}

	if ( 'dates' === $colonne ) {
		$arrivee = get_post_meta( $post_id, 't3_reservation_arrivee', true );
		$depart  = get_post_meta( $post_id, 't3_reservation_depart', true );
		echo esc_html( $arrivee . ' → ' . $depart );
	}

	if ( 'personnes' === $colonne ) {
		echo esc_html( get_post_meta( $post_id, 't3_reservation_personnes', true ) );
	}
}
add_action( 'manage_reservation_posts_custom_column', 't3_hotel_reservation_colonne_contenu', 10, 2 );

/**
 * Récupère les réservations publiées (d'une chambre ou toutes).
 *
 * @param int $chambre_id ID de chambre (0 = toutes).
 * @return array[] Tableau { arrivee: Y-m-d, depart: Y-m-d }.
 */
function t3_hotel_reservations_chambre( $chambre_id = 0 ) {
	$meta_query = array(
		array( 'key' => 't3_reservation_arrivee', 'compare' => 'EXISTS' ),
		array( 'key' => 't3_reservation_depart', 'compare' => 'EXISTS' ),
	);

	if ( $chambre_id > 0 ) {
		$meta_query[] = array(
			'key'   => 't3_reservation_chambre',
			'value' => $chambre_id,
		);
	}

	$query = new WP_Query(
		array(
			'post_type'      => 'reservation',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'no_found_rows'  => true,
			'meta_query'     => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		)
	);

	$reservations = array();

	foreach ( $query->posts as $reservation ) {
		$reservations[] = array(
			'arrivee' => (string) get_post_meta( $reservation->ID, 't3_reservation_arrivee', true ),
			'depart'  => (string) get_post_meta( $reservation->ID, 't3_reservation_depart', true ),
		);
	}

	return $reservations;
}

/**
 * Traite le formulaire de réservation soumis depuis le front.
 */
function t3_hotel_traiter_reservation() {
	$retour = wp_get_referer() ? wp_get_referer() : home_url( '/' );
	$retour = remove_query_arg( array( 'reservation', 'raison' ), $retour );

	if ( ! isset( $_POST['t3_reservation_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['t3_reservation_nonce'] ), 't3_reservation' ) ) {
		wp_safe_redirect( add_query_arg( array( 'reservation' => 'erreur', 'raison' => 'securite' ), $retour ) );
		exit;
	}

	$chambre_id = isset( $_POST['t3_chambre'] ) ? absint( $_POST['t3_chambre'] ) : 0;
	$arrivee    = isset( $_POST['t3_arrivee'] ) ? sanitize_text_field( wp_unslash( $_POST['t3_arrivee'] ) ) : '';
	$depart     = isset( $_POST['t3_depart'] ) ? sanitize_text_field( wp_unslash( $_POST['t3_depart'] ) ) : '';
	$personnes  = isset( $_POST['t3_personnes'] ) ? absint( $_POST['t3_personnes'] ) : 1;
	$nom        = isset( $_POST['t3_nom'] ) ? sanitize_text_field( wp_unslash( $_POST['t3_nom'] ) ) : '';
	$email      = isset( $_POST['t3_email'] ) ? sanitize_email( wp_unslash( $_POST['t3_email'] ) ) : '';
	$telephone  = isset( $_POST['t3_telephone'] ) ? sanitize_text_field( wp_unslash( $_POST['t3_telephone'] ) ) : '';
	$message    = isset( $_POST['t3_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['t3_message'] ) ) : '';

	$date_valide = '/^\d{4}-\d{2}-\d{2}$/';

	if ( ! get_post( $chambre_id ) || get_post_type( $chambre_id ) !== 'chambre'
		|| ! preg_match( $date_valide, $arrivee ) || ! preg_match( $date_valide, $depart )
		|| $arrivee < current_time( 'Y-m-d' ) || $depart <= $arrivee
		|| '' === $nom || ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( array( 'reservation' => 'erreur', 'raison' => 'validation' ), $retour ) );
		exit;
	}

	$conflits = get_posts(
		array(
			'post_type'      => 'reservation',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'relation' => 'AND',
				array(
					'key'   => 't3_reservation_chambre',
					'value' => $chambre_id,
				),
				array(
					'key'     => 't3_reservation_arrivee',
					'value'   => $depart,
					'compare' => '<',
					'type'    => 'DATE',
				),
				array(
					'key'     => 't3_reservation_depart',
					'value'   => $arrivee,
					'compare' => '>',
					'type'    => 'DATE',
				),
			),
		)
	);

	if ( ! empty( $conflits ) ) {
		wp_safe_redirect( add_query_arg( array( 'reservation' => 'erreur', 'raison' => 'indisponible' ), $retour ) );
		exit;
	}

	$reservation_id = wp_insert_post(
		array(
			'post_type'   => 'reservation',
			'post_status' => 'publish',
			'post_title'  => sprintf( '%1$s – %2$s – %3$s', $nom, get_the_title( $chambre_id ), $arrivee ),
		)
	);

	if ( is_wp_error( $reservation_id ) || ! $reservation_id ) {
		wp_safe_redirect( add_query_arg( array( 'reservation' => 'erreur', 'raison' => 'enregistrement' ), $retour ) );
		exit;
	}

	update_post_meta( $reservation_id, 't3_reservation_arrivee', $arrivee );
	update_post_meta( $reservation_id, 't3_reservation_depart', $depart );
	update_post_meta( $reservation_id, 't3_reservation_chambre', $chambre_id );
	update_post_meta( $reservation_id, 't3_reservation_personnes', max( 1, $personnes ) );
	update_post_meta( $reservation_id, 't3_reservation_telephone', $telephone );
	update_post_meta( $reservation_id, 't3_reservation_email', $email );
	update_post_meta( $reservation_id, 't3_reservation_message', $message );

	wp_safe_redirect( add_query_arg( array( 'reservation' => 'succes' ), $retour ) );
	exit;
}
add_action( 'admin_post_t3_reservation', 't3_hotel_traiter_reservation' );
add_action( 'admin_post_nopriv_t3_reservation', 't3_hotel_traiter_reservation' );
