<?php
/**
 * Theme3 Hôtel - Boîtes méta (chambres, témoignages).
 *
 * @package theme3-hotel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Déclare les boîtes méta.
 */
function t3_hotel_add_meta_boxes() {
	add_meta_box( 't3-chambre-details', __( 'Informations chambre', 'theme3-hotel' ), 't3_hotel_chambre_meta_box', 'chambre', 'normal', 'high' );
	add_meta_box( 't3-temoignage-details', __( 'Avis client', 'theme3-hotel' ), 't3_hotel_temoignage_meta_box', 'temoignage', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 't3_hotel_add_meta_boxes' );

/**
 * Boîte méta chambre.
 *
 * @param WP_Post $post Objet courant.
 */
function t3_hotel_chambre_meta_box( $post ) {
	wp_nonce_field( 't3_chambre_meta', 't3_chambre_meta_nonce' );

	$prix        = get_post_meta( $post->ID, 't3_prix', true );
	$capacite    = get_post_meta( $post->ID, 't3_capacite', true );
	$surface     = get_post_meta( $post->ID, 't3_surface', true );
	$equipements = get_post_meta( $post->ID, 't3_equipements', true );
	?>
	<p>
		<label for="t3_prix"><strong><?php esc_html_e( 'Prix par nuit (€)', 'theme3-hotel' ); ?></strong></label><br />
		<input type="number" min="0" step="1" id="t3_prix" name="t3_prix" value="<?php echo esc_attr( $prix ); ?>" style="width:140px;" />
	</p>
	<p>
		<label for="t3_capacite"><strong><?php esc_html_e( 'Capacité (nombre de personnes)', 'theme3-hotel' ); ?></strong></label><br />
		<input type="number" min="1" step="1" id="t3_capacite" name="t3_capacite" value="<?php echo esc_attr( $capacite ); ?>" style="width:140px;" />
	</p>
	<p>
		<label for="t3_surface"><strong><?php esc_html_e( 'Surface (m²)', 'theme3-hotel' ); ?></strong></label><br />
		<input type="number" min="0" step="1" id="t3_surface" name="t3_surface" value="<?php echo esc_attr( $surface ); ?>" style="width:140px;" />
	</p>
	<p>
		<label for="t3_equipements"><strong><?php esc_html_e( 'Équipements (un par ligne)', 'theme3-hotel' ); ?></strong></label><br />
		<textarea id="t3_equipements" name="t3_equipements" rows="6" class="large-text"><?php echo esc_textarea( $equipements ); ?></textarea>
	</p>
	<?php
}

/**
 * Boîte méta témoignage.
 *
 * @param WP_Post $post Objet courant.
 */
function t3_hotel_temoignage_meta_box( $post ) {
	wp_nonce_field( 't3_temoignage_meta', 't3_temoignage_meta_nonce' );

	$note    = get_post_meta( $post->ID, 't3_note', true );
	$sejour  = get_post_meta( $post->ID, 't3_chambre_sejournee', true );
	?>
	<p>
		<label for="t3_note"><strong><?php esc_html_e( 'Note attribuée', 'theme3-hotel' ); ?></strong></label><br />
		<select id="t3_note" name="t3_note">
			<?php for ( $i = 5; $i >= 1; $i-- ) : ?>
				<option value="<?php echo esc_attr( $i ); ?>" <?php selected( (int) $note, $i ); ?>><?php echo esc_html( $i . '/5' ); ?></option>
			<?php endfor; ?>
		</select>
	</p>
	<p>
		<label for="t3_chambre_sejournee"><strong><?php esc_html_e( 'Chambre / séjour concerné', 'theme3-hotel' ); ?></strong></label><br />
		<input type="text" id="t3_chambre_sejournee" name="t3_chambre_sejournee" value="<?php echo esc_attr( $sejour ); ?>" class="large-text" placeholder="<?php esc_attr_e( 'Ex. : Suite Familiale — juillet 2026', 'theme3-hotel' ); ?>" />
	</p>
	<p class="description">
		<?php esc_html_e( 'Le titre du témoignage correspond au nom du client. L\'image mise en avant est utilisée comme photo de profil.', 'theme3-hotel' ); ?>
	</p>
	<?php
}

/**
 * Sauvegarde des boîtes méta.
 *
 * @param int $post_id ID du contenu.
 */
function t3_hotel_save_meta_boxes( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$type = get_post_type( $post_id );

	if ( 'chambre' === $type ) {
		if ( ! isset( $_POST['t3_chambre_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['t3_chambre_meta_nonce'] ), 't3_chambre_meta' ) ) {
			return;
		}

		update_post_meta( $post_id, 't3_prix', isset( $_POST['t3_prix'] ) ? sanitize_text_field( wp_unslash( $_POST['t3_prix'] ) ) : '' );
		update_post_meta( $post_id, 't3_capacite', isset( $_POST['t3_capacite'] ) ? absint( $_POST['t3_capacite'] ) : '' );
		update_post_meta( $post_id, 't3_surface', isset( $_POST['t3_surface'] ) ? absint( $_POST['t3_surface'] ) : '' );
		update_post_meta( $post_id, 't3_equipements', isset( $_POST['t3_equipements'] ) ? sanitize_textarea_field( wp_unslash( $_POST['t3_equipements'] ) ) : '' );
	}

	if ( 'temoignage' === $type ) {
		if ( ! isset( $_POST['t3_temoignage_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['t3_temoignage_meta_nonce'] ), 't3_temoignage_meta' ) ) {
			return;
		}

		update_post_meta( $post_id, 't3_note', isset( $_POST['t3_note'] ) ? max( 1, min( 5, absint( $_POST['t3_note'] ) ) ) : 5 );
		update_post_meta( $post_id, 't3_chambre_sejournee', isset( $_POST['t3_chambre_sejournee'] ) ? sanitize_text_field( wp_unslash( $_POST['t3_chambre_sejournee'] ) ) : '' );
	}
}
add_action( 'save_post', 't3_hotel_save_meta_boxes' );
