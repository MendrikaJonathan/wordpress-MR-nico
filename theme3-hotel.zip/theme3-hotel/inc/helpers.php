<?php
/**
 * Theme3 Hôtel - Fonctions utilitaires.
 *
 * @package theme3-hotel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Retourne l'identifiant de la première page utilisant un modèle donné.
 *
 * @param string $template Nom du fichier de modèle (ex. template-galerie.php).
 * @return int
 */
function t3_hotel_page_par_template( $template ) {
	$pages = get_pages(
		array(
			'meta_key'   => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value' => $template, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'number'     => 1,
		)
	);

	return ! empty( $pages ) ? (int) $pages[0]->ID : 0;
}

/**
 * Retourne l'URL de la page utilisant un modèle donné.
 *
 * @param string $template Nom du fichier de modèle.
 * @return string
 */
function t3_hotel_url_page_template( $template ) {
	$page_id = t3_hotel_page_par_template( $template );

	return $page_id ? get_permalink( $page_id ) : '';
}

/**
 * URL de la page disponibilité.
 *
 * @return string
 */
function t3_hotel_url_disponibilite() {
	return t3_hotel_url_page_template( 'template-disponibilite.php' );
}

/**
 * URL de la page galerie.
 *
 * @return string
 */
function t3_hotel_url_galerie() {
	return t3_hotel_url_page_template( 'template-galerie.php' );
}

/**
 * URL de la page témoignages.
 *
 * @return string
 */
function t3_hotel_url_temoignages() {
	return t3_hotel_url_page_template( 'template-temoignages.php' );
}

/**
 * Menu de secours quand aucun menu principal n'est défini.
 */
function t3_hotel_menu_fallback() {
	echo '<nav class="t3-nav"><ul>';
	wp_list_pages( array( 'title_li' => '' ) );
	echo '</ul></nav>';
}

/**
 * Collecte des images pour la galerie (mises en avant + galeries des chambres).
 *
 * @param int $limite Nombre maximum d'images.
 * @return int[] Identifiants d'images.
 */
function t3_hotel_images_galerie( $limite = 12 ) {
	$images = array();

	$page_id = t3_hotel_page_par_template( 'template-galerie.php' );

	if ( $page_id && has_post_thumbnail( $page_id ) ) {
		$images[] = (int) get_post_thumbnail_id( $page_id );
	}

	$chambres = get_posts(
		array(
			'post_type'      => 'chambre',
			'posts_per_page' => -1,
			'no_found_rows'  => true,
		)
	);

	foreach ( $chambres as $chambre ) {
		if ( has_post_thumbnail( $chambre ) ) {
			$images[] = (int) get_post_thumbnail_id( $chambre );
		}

		$media = get_attached_media( 'image', $chambre );

		foreach ( $media as $image ) {
			$images[] = (int) $image->ID;
		}
	}

	$images = array_values( array_unique( $images ) );

	return array_slice( $images, 0, $limite );
}

/**
 * Liste des équipements d'une chambre.
 *
 * @param int $chambre_id ID de la chambre.
 * @return string[]
 */
function t3_hotel_equipements_chambre( $chambre_id = 0 ) {
	$chambre_id  = $chambre_id ? $chambre_id : get_the_ID();
	$equipements = (string) get_post_meta( $chambre_id, 't3_equipements', true );
	$lignes      = preg_split( '/\r\n|\r|\n/', $equipements );

	return array_values( array_filter( array_map( 'trim', (array) $lignes ) ) );
}
